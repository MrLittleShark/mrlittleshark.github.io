# Re1000

第 2 讲：方腔与ParaView。

## 算例用途

顶盖驱动方腔：流体初始静止，顶盖沿 x 方向运动，其余侧壁静止。使用二维不可压缩层流模型，观察速度、压力与迭代过程。具体几何和物性见下表。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
foamToVTK -latestTime -ascii > log.foamToVTK 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `2` |
| system/controlDict | deltaT | `0.001` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.0001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

方腔的主尺度 L=0.1 m，顶盖速度 U=1 m/s。Re=UL/ν 衡量惯性与黏性作用之比；动量扩散时间 L²/ν 随黏度改变，比较两组时必须说明计算时间是否足以消除启动影响。本目录ν=0.0001m²/s，Re=1000。

采样竖直中线 x=0.05 m、z=0.0025 m，绘制 Ux(y) 并同时保留采样坐标。速度大小不能确定回流方向，应结合速度分量或瞬时流线分析主回流。

icoFoam 的 p 为运动学压力，单位 m²/s²。压力零点平移不改变流速，报告压差时需说明密度与压力定义；输出 CSV 的单元值与点插值值应分别注明。

把后处理从截图扩展为可核对的数据分析：固定采样位置、时刻和色标，比较20×20与加密网格，并在多时刻剖面基本重合后讨论准稳态。该方腔不替代复杂通道的工程建模训练。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 7.537 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/Re1000`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/02_方腔与ParaView/代码/Re1000。当前目录按 v2512 运行并重写说明；原始资料未修改。
