# dimensions

第 3 讲：算例目录与量纲。

## 算例用途

顶盖驱动方腔：流体初始静止，顶盖沿 x 方向运动，其余侧壁静止。使用二维不可压缩层流模型，观察速度、压力与迭代过程。具体几何和物性见下表。

本目录是故障练习，预期求解器报错退出。0/U 的速度量纲错误；将 dimensions 恢复为 [0 1 -1 0 0 0 0]。 修复前后日志应分别保存。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.005` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

先从不可压缩动量方程确定 U、ν、p 的单位，再核对七位量纲数组。U 的量纲为[0 1 -1 0 0 0 0]，ν为[0 2 -1 0 0 0 0]；改变数值不能修复量纲错误。

同时检查网格 boundary 与0目录的场边界。wall 定义网格边界属性，noSlip 定义速度边界条件，两者作用不同；边界名称必须逐字符对应。当前故障将0/U写成运动黏度量纲；修复对象是U，不是p。

正常参照只用于确认同一输入体系可执行。故障算例应记录首条失败命令、报错文件和具体条目，修复后重新运行，避免只依据日志不再报错便结束检查。

将训练结果写成字段核对表：变量定义、单位、文件位置、边界类型、相容条件和修复证据。此表可直接用于T形汇流与多孔通道的输入审查。

## 测试

本次测试状态：PASS；退出码 134；完整脚本耗时 4.34 s。故障例的非零退出是预期报错。

原始日志和数值检查保存在本讲 `测试结果/dimensions`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/03_算例目录与量纲/代码/dimensions。当前目录按 v2512 运行并重写说明；原始资料未修改。
