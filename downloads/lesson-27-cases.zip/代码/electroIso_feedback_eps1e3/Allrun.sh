#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
wmake -j 2 src/myElectroIsoFoam > log.wmake 2>&1
./src/myElectroIsoFoam/myElectroIsoFoam > log.myElectroIsoFoam 2>&1
touch case.foam
