# 电流反馈与孔口注气：electroIso_feedback_eps1e3

本例计算移动气泡遮蔽导电区域后，电极电流与孔口注气率的双向影响。

## 模型定义

本例表示电极产气经理想集气装置收集后，从中心孔口注入气泡的等效过程。环形电极产生的气体不直接在各电极面上生成VOF体积源；其总产气率经集气后统一成为孔口边界流量。模型求解流动、移动气液界面、稳态导电和入口产气反馈，未求解微观成核、溶解气体扩散、Henry分配及移动界面传质。

计算域为5°轴对称楔形，半径4 mm、高8 mm。中心孔口半径0.25 mm；环形电极由0.25 mm延伸至1 mm；其余底面为绝缘基底。环形电极电势2 V，顶部0 V。孔口、侧壁和外围基底均为电学绝缘，流入气体不会通过孔口携带电流。流动边界中孔口速度由电流更新，环形电极及基底为noSlip，顶面为压力出口。全部固体的边界theta0=90°。该几何与边界绕轴保持不变。

径向三段分别为4、12、24个单元，轴向0–2 mm和2–8 mm各40层，共3200个单元。初始气泡为半径0.4 mm的半球，通过setFields按单元中心初始化。水和氢气的物性写在constant/transportProperties；气体换算温度293.15 K、绝对压力101325 Pa，与采用的约20 ℃氢气密度0.0838 kg/m³一致。

## 方程、单位与反馈关系

以alpha=alpha.water表示液相体积分数。两相体积分数由isoAdvector输运，界面采用plicRDF重构。混合密度为rho=alpha rho_l+(1−alpha)rho_g。速度满足不可压缩体积连续性方程div(U)=0和含重力、黏性及表面张力的动量方程。由于产气从边界输入，域内没有由电极反应直接产生的相分数体积源。

电导率定义为kappa=kappa_l[alpha+epsilon(1−alpha)]，其中kappa_l=20 S/m。电势Velec的单位为V，电流密度i=−kappa grad(Velec)，单位A/m²。每个流动时间步求解div(kappa grad(Velec))=0。0/Velec中的内部零值为首个稳态线性系统提供迭代初猜；电势方程无时间导数，每一步求解当前界面对应的导电场。气体电导率epsilon kappa_l为维持线性系统可解性设置的正则化参数，并非氢气真实电导率。epsilon设为零会使气相内部导电方程退化；因此需要比较多个足够小的正值，并单独检查网格影响。

面电导率采用调和插值，即kappa_f=1/interpolate(1/kappa)。高、低电导率单元相邻时，调和插值保留低电导区域的主要阻力，避免简单算术平均过度增大跨界面电流。混合单元中的电导率仍由体积分数插值给定，因此界面厚度与网格尺寸会影响近界面导电分布。

设电极流入计算域的电流为I，则I=−integral(i·n dA)，n为计算域外法向。底部n沿负y，给定电极正电势时电流向上进入液体，I为正。求解器由电势矩阵的离散面通量积分得到电极电流和顶部电流，使电流检查与实际离散方程采用同一通量。

氢气反应的电子转移数z=2。摩尔产气率为eta I/(zF)，其中本例集气效率eta=1，F=96485.33212 C/mol。孔口体积流量Q=eta IRT/(zFp_abs)，R=8.314462618 J/(mol·K)。孔口速度Uin=Q/Ain，方向为正y。电极面积和孔口面积不同，不能直接用电极电流密度替代孔口速度。

RT/p采用给定绝对压力。初始球面Laplace压差约2σ/R=360 Pa，为参考绝对压力的0.36%，本例采用恒压体积换算。若研究更小气泡或较大压力变化，应在摩尔量到体积率的换算中更新气泡压力，并重新验证收支。当前incompressible两相方程未求解气体压缩过程。

## 程序执行顺序

所有源码均在src/myElectroIsoFoam，保留本机interIsoFoam与其依赖头文件。新增createElectroFields.H读取电模型参数、创建电势、电导率和电流密度场，并建立electroBalance.csv。updateElectricity.H用当前alpha计算电导率、求解电势、积分电流、更新孔口速度及边界phi。recordElectricity.H记录每一步的电流、累计电荷、气体体积与误差。

在时间步开始时用alpha^n求得I^n和Q^n。改变孔口速度后先通过CorrectPhi求解辅助压力方程，对面体积通量进行投影，保证界面输运使用连续的phi。随后执行几何VOF输运、动量求解和压力校正，得到alpha^(n+1)与速度场。若只改入口U却不修正phi，界面方程可能使用与新边界流量不相容的面通量。

该分步耦合在时间上为显式更新，电势与流量由时间步起点的界面决定。CSV中的time为更新后流动时刻，electricTime=time−dt为该行导电场对应的界面时刻。输出电势比同目录中的alpha落后一个时间步；当前步长远小于保存间隔，但读取场图和进行时间步研究时仍需区分两个时刻。

```cpp
kappa = sigmaL*(alpha1 + epsilon*(1-alpha1));
surfaceScalarField kappaf("kappaf",1.0/fvc::interpolate(1.0/kappa));
fvScalarMatrix electricEqn(fvm::laplacian(kappaf,Velec));
electricEqn.solve();
```

上式为便于说明的核心关系，完整源码包含相分数范围限制、量纲声明、电流符号检查和边界赋值。修改电压时编辑0/Velec，修改电导率比、温度或反馈开关时编辑constant/electroProperties。只有更改C++实现时才需要重新编译。

## 编译与运行

进入当前目录并加载v2512环境后执行`./Allrun.sh`。所有案例均包含各自源码和Make文件，程序输出至src/myElectroIsoFoam/myElectroIsoFoam。编译记录在log.wmake，求解记录在log.myElectroIsoFoam。

```sh
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
wmake -j 2 src/myElectroIsoFoam > log.wmake 2>&1
./src/myElectroIsoFoam/myElectroIsoFoam > log.myElectroIsoFoam 2>&1
```

wmake的-j 2允许至多两个并行编译任务；src/myElectroIsoFoam指定源目录。Make/files指定主程序和本例可执行文件位置，Make/options链接当前OpenFOAM的几何VOF、有限体积、物性和湍流模型库。源码与链接库须属于同一v2512环境。

## 守恒检查与模型检验

全周量由5°楔形积分乘72得到。入口速度的计算在楔形域内完成，电流和面积采用同一几何范围，角度系数在其比值中相消。网格边界是平面离散面，实际面积应从网格读取，不能一处使用精确圆面积、另一处使用离散楔形面积而不说明差异。

每一步按实际时间步累计电荷：C^(n+1)=C^n+I_applied^n Δt。预期气体体积为V_expected=V0+eta RT C/(zFp)。实际气体体积为sum[(1−alpha_i)Vi]。电流不平衡为|I_electrode−I_top|/|I_electrode|，体积收支误差为(Vgas−Vexpected)/Vexpected。

独立制作阶段还按blockMesh实际单元几何重新计算体积积分，与C++原生积分比较。该检查检验字段读取、单元体积权重和全周换算。α有界、电荷守恒和气体体积守恒并不等同于界面形状或速度已经达到网格无关，应分别检查近接触线网格、毛细时间步、气体电导率和初始化方法。

气体连通性采用alpha.water<0.5、共享面相邻的单元识别，至少8个单元构成候选区域。选取气体体积最大的区域，检查是否与底面相连。电极气泡的质心升高不能替代该连接判据。当前30 ms计算用于附着生长，不提供脱落时刻或脱落半径。

## 本例设置与实际结果

电导率比epsilon=0.001，currentFeedback=true。末时刻0.03 s，电极电流由0.11966788 A变为0.11268441 A，相对变化-5.83571%。该末次电流对应electricTime=0.0299943552 s。

实际气体体积由1.3139215007e-10增至5.6596326081e-10 m³；累计输入电荷为3.4861387877e-03 C。最终体积收支相对误差为-4.676068e-10，全过程最大电流不平衡为1.714079e-10。独立网格积分与C++积分相对差异为1.388467e-14。

本例每一步将当前电流用于孔口输入。气泡覆盖区域变化会改变导电路径，电流变化进一步改变下一步注气体积，形成明确的双向反馈。

最终保存场中，液相alpha>0.99区域的最大速度为0.227291 m/s，气相alpha<0.01区域为1.87261 m/s。低密度气相中的局部速度明显高于液相；该量不能解释为气泡上升速度。定量研究局部流动时还需检验毛细离散误差和网格分辨率。

## 复核与研究练习

1. 从网格读取孔口面积，用实际入口速度计算体积流量；与日志和体积增长比较。
2. 在独立目录中加密近接触线网格，并保持其余输入不变，比较壁面界面位置和液相速度。
3. 将最大时间步减半，比较同一物理时刻的体积、质心和边界电流；记录与当前结果的相对变化。
4. 保存修改后的字典、Allrun.sh、完整日志和原始场。

## 依据

求解器与工具实现依据本机OpenCFD v2512的interIsoFoam、isoAdvection、plicRDF、setAlphaField和有限体积电势离散源码。经典几何VOF方法背景：Roenby、Bredmose与Jasak（2016），A computational method for sharp interface advection，Royal Society Open Science，doi:10.1098/rsos.160405。本例新增导电—集气注气关系以随附源码和离散收支检查为准。
