# potential_primary

第 27 讲：电极气泡_电势与脱落。

## 算例用途

稳态电势问题，T 的量纲为 V，代表溶液电势，电导率取 1 S/m。primary 为定值平板，mixed 为线性动力学，ButlerVolmer 为非线性动力学；insulating_bubble 含固定绝缘半球障碍。各目录为独立电势模型，不与移动 VOF 实时耦合。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

本例 T 表示电势，V，量纲由 dimensions 指定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
laplacianFoam > log.laplacianFoam 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `30` |
| system/controlDict | deltaT | `1` |
| system/controlDict | writeInterval | `30` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 1` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |

实际网格：单元数 480。

## 文件与阅读顺序

- `0/T`：标量初值与边界，本例物理意义见上文。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

本例 endTime 与实际测试时长见上表和测试记录。长时算例可在课前完成，课堂演示使用已保存的时间序列。是否发生脱落或形成周期，按实际结果与判据判断。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 2.716 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/potential_primary`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/22_电势与气泡遮蔽/代码/primary。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：验证算例。保留解析/几何电流基准，作为新增导电率—界面反馈求解器的分步验证。

电势问题应检查各边界电流积分、反应边界的单位和导电率正则化。移动气泡问题还需检查累计注气量和气体体积。脱落以共享面连通性及壁面接触状态定义，未脱落区间没有可报告的脱落半径。

应量化的内容：电流收支、正则化敏感性、体积收支、气相连通与实际脱落状态。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。

已有运行数据（指标定义见数值检查记录）：

- `boundary_flux`：10.000000000003334

平板定值和线性动力学例应先与解析电流比较，再用于检验含固定绝缘气泡的几何电流分布。非线性Butler–Volmer例需检查迭代收敛和小过电位极限，而非把线性参考值当作任意电位下的精确解。
