# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`electroIso_feedback_eps1e4`。参数对照和基础验证分别见以下独立目录。

- [injection_N24_theta120](injection_N24_theta120/README.md)
- [injection_N24_theta60](injection_N24_theta60/README.md)
- [injection_N24_theta90](injection_N24_theta90/README.md)
- [potential_primary](potential_primary/README.md)
- [potential_mixed](potential_mixed/README.md)
- [potential_insulating_bubble](potential_insulating_bubble/README.md)
- [potential_insulating_bubble_mixed](potential_insulating_bubble_mixed/README.md)
- [potential_ButlerVolmer](potential_ButlerVolmer/README.md)
- [marangoni_given_gradient](marangoni_given_gradient/README.md)
- [detachment_theta90](detachment_theta90/README.md)
- [electroIso_feedback_eps1e4](electroIso_feedback_eps1e4/README.md)
- [electroIso_feedback_eps1e3](electroIso_feedback_eps1e3/README.md)
- [electroIso_frozenCurrent_eps1e4](electroIso_frozenCurrent_eps1e4/README.md)
