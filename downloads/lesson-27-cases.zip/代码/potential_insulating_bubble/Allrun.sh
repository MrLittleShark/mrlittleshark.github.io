#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh > log.checkMesh.2 2>&1
laplacianFoam > log.laplacianFoam 2>&1
postProcess -func 'grad(T)' -latestTime > log.postProcess 2>&1
postProcess -latestTime -fields '(T)' > log.postProcess.2 2>&1
touch case.foam
