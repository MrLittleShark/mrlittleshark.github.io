# 后台阶湍流分离与再附着

## 工程算例：后台阶湍流分离与再附着

### 几何、流动与研究量

后台阶使来流边界层离开壁面，在台阶后形成分离剪切层和回流区，随后在下游再附着。本例采用本机 v2512 的 backwardFacingStep2D 网格，以台阶高度 h=0.0127 m 为长度尺度。入口位于 x/h=−130，出口位于 x/h=50，网格共 20540 个单元。前后平面为 empty，表示二维平均流动，不能用于预测三维湍流瞬时结构。

入口速度为 44.2 m/s，运动黏度为 1.56×10⁻⁵ m²/s，Re_h=35983.3。入口上、下游短段采用对称边界，随后设置无滑移壁面，使边界层在到达台阶前发展。出口指定运动学压力为零，速度采用零梯度。长入口段的作用需要从台阶前剖面验证，而不能只依据其长度推断边界层符合实验。

### RANS 模型与近壁条件

稳态 RANS 动量方程包含平均对流、压力梯度、分子黏性应力和雷诺应力。kOmegaSST 通过 k 和 ω 两个输运方程计算湍动能和比耗散率，并由涡黏性近似封闭雷诺应力。SST 的混合函数与应力限制参与近壁和外层计算，模型选择不能只由目录中的 RASModel 名称判断，还应核对其余物性与壁面条件。

入口 k=0.00109 m²/s²、ω=181728 s⁻¹，均取自官方基准。由 I=√(2k/3)/U 得到入口湍流强度 0.06099%。这组输入描述弱湍流来流在长壁面上发展的配置，不应换算为未经验证的通道水力尺度后宣称普适。当前台阶前 x/h=−4 处参考速度 Uref=46.5845 m/s，按下壁面起算的 δ99/h≈1.3468；实验说明中的边界层厚度约为 1.5h，该差异需要纳入结果解释。

近壁网格沿法向分级，采用 nutUBlendedWallFunction、omegaWallFunction 和 kqRWallFunction。当前下壁 yPlus 范围为 0.0023693–5.1222，面积加权均值 1.5277；上壁均值 1.2457。这是细近壁网格配合混合壁函数的设置，不能仅因大部分 yPlus 接近 1，就称为完全解析黏性底层的低雷诺数模型。尖角附近应单独查看局部网格及壁面量，不能只报告平均 yPlus。

### 离散、松弛与收敛

本例采用 steadyState 时间格式，5000 表示 SIMPLE 迭代次数，不是 5000 s。速度对流采用 bounded Gauss linearUpwind grad(U)，梯度采用 cellLimited Gauss linear 1，湍流变量采用有界上风输运。压力场松弛为 0.3，速度和湍流方程松弛为 0.5。这些设置用于降低初始过渡中的非线性振荡，同时保留速度方程的梯度修正。

最后 200 次的压力初始归一化残差在约 9.91e-05–0.000125 之间波动。最后一次 Ux、Uy 初始残差分别为 1.07e-08 和 7.3e-08，不能把这些变量的归一化数值当作同一量纲的误差比较。最后两个保存结果之间的速度场相对 L2 变化为 3.45e-06，最后 250 次再附着位置变化为 1.78e-06h，进出口体积通量相对不平衡为 1.56e-09。这些指标分别描述代数迭代、目标量稳定性和质量守恒。

### 再附着、压力恢复与实验对照

本例在台阶后平直底壁提取壁面剪切，按正向流动对应正 Cf 的约定计算摩擦系数，使用 Cf 由负变正的零点确定主回流区再附着。排除靠近角点的小回流后，得到 x_r/h=6.48459。Driver–Seegmiller 实验值为 6.26±0.10，本次计算相对其中心值偏大 3.588%。该差异超过实验所列再附着不确定度，需要进一步比较网格、入口发展边界层和模型误差，不能以求解完成替代实验验证。

入口减出口的面积平均运动学静压差为 -12.3356 m²/s²，负值表示扩张后的静压恢复。能量损失另用总压衡量：将 p+|U|²/2 按边界通量加权，本次运动学总压损失为 147.0507 m²/s²。静压恢复与总压损失可以同时发生，二者不能混用。

### 运行与后续研究

进入代码/backward_step_SST 后运行 ./Allrun.sh。脚本依次执行 blockMesh、checkMesh、simpleFoam、yPlus 后处理和 VTK 输出。system/sample 保留 x/h=1、4、6、10 的速度采样；reference/cf.exp.dat 保存公开实验摩擦系数数据，图中已叠加误差棒。后续网格研究应同时细化剪切层和近壁单元，并保持入口、离散设置及停止准则一致，再比较再附着位置、δ99 和总压损失。

实验条件与数据来源：[Turbulence Modeling Resource 后台阶验证案例](https://tmbwg.github.io/turbmodels/backstep_val.html)。当前计算输入由本机 v2512 官方教程定制。

## 本目录运行

先加载环境，再在本目录执行：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

本目录 Allrun.sh：

```bash
#!/bin/bash
set -e
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
simpleFoam > log.simpleFoam 2>&1
simpleFoam -postProcess -func yPlus -latestTime > log.yPlus 2>&1
foamToVTK -latestTime -ascii > log.foamToVTK 2>&1
touch case.foam
```

## 本次测试结果

完整运行记录位于本讲 `测试结果/backward_step_SST`，包含退出码、参数指纹、执行脚本和原始日志。数值检查结果如下：

```json
{
  "case": "backward_step_SST",
  "lesson": 15,
  "solver": "simpleFoam / kOmegaSST",
  "final_time": 5000.0,
  "iteration_count": 5000,
  "cells": 20540,
  "Re_step": 35983.333333333336,
  "inlet_U_m_s": 44.2,
  "inlet_k_m2_s2": 0.00109,
  "inlet_omega_s_inverse": 181728,
  "inlet_turbulence_intensity": 0.0006098813459775483,
  "Uref_m_s": 46.58451147,
  "reattachment_x_over_h": 6.484587549344328,
  "reference_reattachment_x_over_h": 6.26,
  "reference_uncertainty_h": 0.1,
  "relative_reattachment_difference": 0.03587660532656995,
  "k_min": 6.483947441e-07,
  "omega_min": 320.1987125,
  "maximum_speed_m_s": 47.025455021036635,
  "mass_conservation_relative": 1.5631709750245532e-09,
  "kinematic_pressure_drop_m2_s2": -12.335633418029044,
  "last_saved_velocity_relative_change": 3.454659232333001e-06,
  "yPlus": {
    "lowerWall": {
      "min": 0.002369266728,
      "max": 5.122168942,
      "area_weighted_mean": 1.5277325438468057
    },
    "upperWall": {
      "min": 0.4739065268,
      "max": 1.921601805,
      "area_weighted_mean": 1.2457357480190596
    }
  },
  "wall_treatment": "nutUBlendedWallFunction, omegaWallFunction, kqRWallFunction; graded near-wall mesh",
  "reference_url": "https://tmbwg.github.io/turbmodels/backstep_val.html",
  "passed": true,
  "mass_weighted_total_pressure_loss_m2_s2": 147.05072695350702,
  "upstream_boundary_layer_delta99_over_h": 1.3467657096294046,
  "reattachment_history_x_over_h": [
    [
      4000,
      6.484558602211674
    ],
    [
      4250,
      6.4845743676395475
    ],
    [
      4500,
      6.484581983153042
    ],
    [
      4750,
      6.484585768998122
    ],
    [
      5000,
      6.484587549344328
    ]
  ],
  "last_250_reattachment_change_h": 1.7803462055709929e-06,
  "convergence_interpretation": "最后 200 次压力初始归一化残差在所列范围波动；速度场变化、再附着位置和质量收支分别检查。单一网格与实验的差异不能全部归因于湍流模型。"
}
```

## 文件阅读顺序

先读 system/blockMeshDict（多区域使用 system/fluid 与 system/solid），再读 0 中的场条件、constant 中的模型与物性，最后核对 fvSchemes、fvSolution 和 controlDict。全部输入位于当前目录，运行不依赖其他课次。
