#!/bin/bash
set -e
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
simpleFoam > log.simpleFoam 2>&1
simpleFoam -postProcess -func yPlus -latestTime > log.yPlus 2>&1
foamToVTK -latestTime -ascii > log.foamToVTK 2>&1
touch case.foam
