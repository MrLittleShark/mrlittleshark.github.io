# T形双入口混合：等流量

本例为独立流动案例，包含完整几何、初始场、边界、数值格式与运行命令。

## 运行

在本机OpenFOAM v2512环境中进入本目录，执行：

```sh
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的命令如下：

```sh
#!/bin/sh
set -e
blockMesh > log.blockMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh 2>&1
pimpleFoam > log.pimpleFoam 2>&1
postProcess -func writeCellCentres -latestTime > log.cellCentres 2>&1
postProcess -func writeCellVolumes -latestTime > log.cellVolumes 2>&1
touch case.foam
```

每条命令的日志保存在当前目录。修改参数时复制完整目录，保留原输入和结果，再运行新的参数组。使用ParaView打开case.foam；选择实际保存时刻并核对变量单位。

## 几何、方程与无量纲数

主通道长140mm、高10mm，支路x=15–25mm、顶端y=30mm，厚度1mm。入口A为(0.3,0,0)m/s，入口B为(0,−0.3,0)m/s。壁面noSlip，前后empty，出口p=0。

速度满足不可压缩Navier–Stokes方程。归一化浓度满足∂c/∂t+∇·(Uc)=D∇²c，ν=1.5e−5m²/s、D=2e−5m²/s。Sc=0.75；入口A的Re=200、Pe=150。入口A浓度0，入口B浓度1，初始c=0。浓度不改变流体物性。

## 数值方法与监测

pimpleFoam求解U和p，scalarTransport函数对象用当前phi推进c。0/c、div(phi,c)格式及c线性求解器均在本目录。PIMPLE外迭代2次、压力修正2次；时间格式backward，浓度对流limitedLinear 1。Δt=0.0005s，计算至1.2s，场每0.15s保存。6400单元网格通过扩展几何与拓扑检查。

flow_inletA、flow_inletB和flow_outlet输出面通量和；tracerMean输出phi加权浓度。壁面及出口浓度为零梯度。出口流动方向必须检查；此前60mm短出口试算存在边界回流，最终两组统一延长后重算。

## 实际结果

入口流量分别为3e-06与3e-06m³/s，出口6.00000000002e-06m³/s，相对体积不平衡3.833e-12。最终c范围[5.51495e-41,1]。

出口通量加权平均浓度为0.49991274，流量配比理论值为0.50000000。加权方差为0.06659978，混合指数M=0.48386132。平均值与方差必须同时报告。

## 收支与混合指标的计算

出口完全流出时，定义wf=φf/Σφf、c̄=Σwfcf、σ²=Σwf(cf−c̄)²。对纯示踪入口0和1，M=1−sqrt[σ²/(cideal(1−cideal))]。面积平均与通量加权平均不同；有负通量时，不能直接把这组权重用于概率型方差解释。

域内库存Ic=ΣcV。两个时刻间的库存变化应与同一时段内对流、扩散净通量积分比较。当前瞬态库存尚有微小变化，终点平均浓度与理论极限的偏差需结合库存项分析，不应直接称作质量损失。

## 参数研究

固定总流量改变两入口分配，可减少总停留时间变化的影响。另建网格0.25mm、时间步减半的对照，比较出口均值、方差、回流长度及压降，检查数值扩散是否高估混合。二维empty模型不表示三维二次流。

## 测试与来源

本目录Allrun.sh已实际执行，退出码0。测试结果、脚本快照、数值检查和原始日志见本讲“测试结果/Tmix_equal”。运行时间取日志中的求解器ClockTime；网格案例取snappyHexMesh耗时，未将其写成完整课堂操作耗时。

独立构建 T 形混合通道；参考本机 v2512 pimpleFoam/RAS/TJunction 的 scalarTransport 接口。
