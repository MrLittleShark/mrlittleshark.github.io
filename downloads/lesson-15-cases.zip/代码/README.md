# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`backward_step_SST`。参数对照和基础验证分别见以下独立目录。

- [transient_residuals](transient_residuals/README.md)
- [open_channel](open_channel/README.md)
- [Tmix_equal](Tmix_equal/README.md)
- [Tmix_unequal](Tmix_unequal/README.md)
- [backward_step_SST](backward_step_SST/README.md)
