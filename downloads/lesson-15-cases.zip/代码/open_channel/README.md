# open_channel

第 15 讲：残差与边界条件。

## 算例用途

本例采用入口定速度、出口定压力的开口通道，检查边界通量相容性和压力参考。网格 patch 类型、边界名称和场条件分别读取；名称为 wall 不会自动给速度施加 noSlip。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.2` |
| system/controlDict | deltaT | `0.0025` |
| system/controlDict | writeInterval | `0.2` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.01` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 300。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 3.268 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/open_channel`。测试参数与计算时段见运行记录。

## 定量分析与后续验证

当前 deltaT=0.0025 s，设定终止时刻 0.2 s，实际保存至 0.2 s；速度分量范围为 [-0.1653718, 1.275325] m/s，运动学压力范围为 [0.03273028, 2.45492] m²/s²。

按网格边界面积及场文件逐项计算进出流量，核对 phi 是体积通量还是质量通量。改变出口边界之前，应判断是否存在回流以及域外回流状态。新增 backward_step_SST 提供具有分离区和长入口段的工程边界条件训练。

## 来源

课程原有 v2512 独立算例。原始输入、Allrun.sh 及既有测试记录保留；本次补充模型说明、实际统计和后续对照要求。
