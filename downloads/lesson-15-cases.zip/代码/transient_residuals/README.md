# transient_residuals

第 15 讲：残差与边界条件。

## 算例用途

本例采用封闭方腔启动过程，研究瞬态物理变化与每次线性求解残差的区别。下一时间步的初始残差可能重新升高，应同时记录最终残差和速度发展；残差曲线不直接表示网格误差或达到稳态。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.5` |
| system/controlDict | deltaT | `0.005` |
| system/controlDict | writeInterval | `0.5` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 3.217 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/transient_residuals`。测试参数与计算时段见运行记录。

## 定量分析与后续验证

当前 deltaT=0.005 s，设定终止时刻 0.5 s，实际保存至 0.5 s；速度分量范围为 [-0.4904209, 0.8382598] m/s，运动学压力范围为 [-0.3435746, 0.7365337] m²/s²。

把同一时段的 Ux 初始残差、最终残差和监测点速度分别绘图，说明每条曲线对应的量。继续计算时先明确是否研究最终稳态或启动瞬态，再确定结束条件。新增 backward_step_SST 将相同诊断用于湍流分离、再附着及近壁处理。

## 来源

课程原有 v2512 独立算例。原始输入、Allrun.sh 及既有测试记录保留；本次补充模型说明、实际统计和后续对照要求。
