# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`posts_layers_success`。参数对照和基础验证分别见以下独立目录。

- [layers](layers/README.md)
- [posts_snap_reference](posts_snap_reference/README.md)
- [posts_layers_success](posts_layers_success/README.md)
