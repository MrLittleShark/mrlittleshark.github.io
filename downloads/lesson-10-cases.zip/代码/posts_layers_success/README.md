# 圆柱凸起阵列：成功壁面层

本例为纯网格案例，比较几何贴合、壁面层与质量控制。

## 运行

在本机OpenFOAM v2512环境中进入本目录，执行：

```sh
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的命令如下：

```sh
#!/bin/sh
set -e
blockMesh > log.blockMesh 2>&1
surfaceCheck constant/triSurface/posts.stl > log.surfaceCheck 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh > log.checkMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh.extended 2>&1
touch case.foam
```

每条命令的日志保存在当前目录。修改参数时复制完整目录，保留原输入和结果，再运行新的参数组。使用ParaView打开case.foam；选择实际保存时刻并核对变量单位。

## 几何与网格设计

背景域4mm×4mm×4mm，16×16×16背景单元，圆柱凸起表面一级细化，局部尺度约125μm。柱体半径0.3mm、露出底面的高度1.5mm。STL和网格内部统一使用米，surfaceCheck与checkMesh分别核对表面和体网格的包围盒。

本目录addLayers=true，目标2层，expansionRatio=1.2，finalLayerThickness=0.15，minThickness=0.025，均采用relativeSizes=true。按125μm局部尺度，首层目标15.625μm，最外层18.75μm，总厚34.375μm。

## 绝对尺度与质量控制

minVol设为正值1e−18m³，表示面锥体积的绝对下限。旧例1e−13对毫米尺度薄层过大，导致挤出被撤回。新例没有取消正体积及四面体质量检查；非正交、偏斜度、面权重和体积比限制仍保留。该参数调整应结合实际尺度推导。

## 实际结果

最终单元数10538，最小体积8.32552e-14m³，最大非正交角28.186°，最大偏斜度0.5863。标准checkMesh通过。

目标852个壁面中，704面2层、64面1层、84面0层；面数覆盖率90.14%，新增1472层单元。全目标面总层厚均值27.49μm，已覆盖面均值30.50μm。诊断字段位于0/nSurfaceLayers、0/thickness与0/thicknessFraction，属于网格生成结果。

扩展-allGeometry/-allTopology检查报告374个凹形多面体；完整结果保存在log.checkMesh.extended。该项没有判为通过。可用concaveCells选区定位并结合局部梯度需求分析，正式流动模型仍需进行网格和格式研究。

## 分析与参数研究

近壁梯度依赖第一层距离及其后网格分布，不能只用单元总数评价。固定几何和细化，分别改变层数与总厚度，比较实际覆盖、质量极值和凹形单元位置。理论层厚、实际层厚和平均值应分别报告。

本例不推进物理流动，不产生速度或壁面应力结果。若用于层流，依据目标梯度的网格收敛评价；若用于壁面湍流模型，再按相应模型检查y⁺。

## 测试与来源

本目录Allrun.sh已实际执行，退出码0。测试结果、脚本快照、数值检查和原始日志见本讲“测试结果/posts_layers_success”。运行时间取日志中的求解器ClockTime；网格案例取snappyHexMesh耗时，未将其写成完整课堂操作耗时。

课程既有 posts.stl 凸起几何；独立设置毫米尺度绝对体积阈值。
