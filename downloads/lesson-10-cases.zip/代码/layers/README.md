# layers

第 10 讲：snappyHexMesh网格生成。

## 算例用途

检查凸起表面的壁面层设置。layers 为基准；layers_thinner 减小目标层厚；layers_more 增加目标层数。当前三组均未生成壁面层。 本例不执行流场求解。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
surfaceCheck constant/triSurface/posts.stl > log.surfaceCheck 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh > log.checkMesh.2 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.001` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 1.0` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |
| system/snappyHexMeshDict | nSurfaceLayers | `2` |
| system/snappyHexMeshDict | finalLayerThickness | `0.3` |
| system/snappyHexMeshDict | expansionRatio | `1.2` |

实际网格：单元数 9066。

## 文件与阅读顺序

- `0/pointLevel`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `0/thickness`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `0/thicknessFraction`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `0/cellLevel`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `0/nSurfaceLayers`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `constant/triSurface/posts.vtp`：当前算例的输入文件，具体设置见文件注释。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/snappyHexMeshDict`：当前算例的输入文件，具体设置见文件注释。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

旧例minVol=1e−13表示最小面锥体积的绝对阈值，单位m³。毫米尺度薄层对应的面锥体积可能小于该阈值，即使单元体积为正也会被层生成质量控制撤回。

单独减小层厚或增加目标层数不能解除不合理绝对阈值造成的限制。应从日志中定位非法面数量、被撤回的挤出面及最终层数，再决定参数调整。

主练习改用posts_snap_reference与posts_layers_success。新成功例保持正的minVol=1e−18，目标2层，最终覆盖768/852个壁面，其中704面2层、64面1层；体积负值检查和其他质量条件仍保留。

新例标准checkMesh通过，但扩展几何检查仍有374个凹形多面体，应结合位置与离散方法继续评估。旧三组输入只保留为诊断材料，不能继续作为三组有效壁面层网格进行流动比较。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 5.36 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/layers`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/10_snappyHexMesh实战/代码/layers。当前目录按 v2512 运行并重写说明；原始资料未修改。
