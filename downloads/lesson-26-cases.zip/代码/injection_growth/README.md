# injection_growth

第 26 讲：电极气泡_产气与生长。

## 算例用途

轴对称气泡：使用 5 度 wedge 表示完整旋转体。alpha.water=1 为水，0 为气体。初始区域由本目录的 alpha.water 或 setFieldsDict 指定，重力由 constant/g 给出。底部中心孔口指定气体速度 0.05 m/s，观察注气引起的体积增长与附着状态。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
interFoam > log.interFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `interFoam` |
| system/controlDict | endTime | `0.03` |
| system/controlDict | deltaT | `1e-05` |
| system/controlDict | writeInterval | `0.002` |
| constant/transportProperties | nu | `1e-6` |
| constant/transportProperties | sigma | `0.072` |
| 0/alpha.water | theta0 | `90` |
| system/fvSolution | nCorrectors | `3` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 1152。

## 文件与阅读顺序

- `0/p_rgh`：去除重力静压后的压力，单位 Pa。
- `0/U`：速度初值和各边界，单位 m/s。
- `0/alpha.water`：水体积分数初值与接触角或回流条件。
- `0/uniform/time`：当前算例的输入文件，具体设置见文件注释。
- `constant/g`：重力方向与大小。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/setFieldsDict`：当前算例的输入文件，具体设置见文件注释。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

本例 endTime 与实际测试时长见上表和测试记录。长时算例可在课前完成，课堂演示使用已保存的时间序列。是否发生脱落或形成周期，按实际结果与判据判断。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 82.453 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/injection_growth`。测试参数与计算时段见运行记录。

## 来源

26_电极气泡_产气与生长/代码/injection_N24_theta90；独立延长计算时长。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：验证算例。保留，补充推导、定量定义和参数研究。

Faraday关系首先给出摩尔率，体积流量还取决于温度、绝对压力及气体收集假设。注气体积检查采用V0+积分Qdt，不能忽略初始气泡。固定界面分配模型与移动界面输运分别验证。

应量化的内容：Faraday换算、累计输入与体积收支、相间分配验证、注气与传质区别。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。

已有运行数据（指标定义见数值检查记录）：

- `end_time`：0.02999703081
- `initial_gas_volume`：4.0932133976735996e-11
- `final_gas_volume`：3.35613940857535e-10
- `injection_volume_error`：0.0005564411842240435
