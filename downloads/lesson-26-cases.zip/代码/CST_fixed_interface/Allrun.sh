#!/bin/sh
set -e

python3 CST.py > log.CST 2>&1
