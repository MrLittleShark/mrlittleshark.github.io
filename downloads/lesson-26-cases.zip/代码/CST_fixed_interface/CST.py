"""固定界面CST教学验证，仅依赖numpy；进入本目录后执行 Allrun.sh。"""
from pathlib import Path
import json
import numpy as np

def run(work):
    N=160;dx=1/N;H=np.where(np.arange(N)<N//2,.2,1.);D=np.where(np.arange(N)<N//2,1.,4.)
    K=D*H;Kf=2*K[:-1]*K[1:]/(K[:-1]+K[1:]);psi=np.where(np.arange(N)<N//2,3.,.2)
    mass0=np.sum(H*psi)*dx;dt=.0005;L=np.r_[0,Kf]/dx**2;R=np.r_[Kf,0]/dx**2
    diag=H+dt*(L+R);lower=-dt*L;upper=-dt*R
    pivot=diag.copy();factors=np.zeros(N)
    for i in range(1,N):factors[i]=lower[i]/pivot[i-1];pivot[i]-=factors[i]*upper[i-1]
    for _ in range(2000):
        rhs=H*psi
        for i in range(1,N):rhs[i]-=factors[i]*rhs[i-1]
        psi[-1]=rhs[-1]/pivot[-1]
        for i in range(N-2,-1,-1):psi[i]=(rhs[i]-upper[i]*psi[i+1])/pivot[i]
    c=H*psi;err=abs(np.sum(c)*dx/mass0-1);ratio=float(np.mean(c[:N//2])/np.mean(c[N//2:]));assert err<1e-8 and abs(ratio/.2-1)<1e-3
    out={'mass_relative_error':float(err),'Henry_ratio':ratio,'target_ratio':.2,'scope':'1D fixed interface, no VOF feedback'}
    work=Path(work);(work/'cst_result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    np.savetxt(work/'cst_equilibrium.csv',np.c_[(np.arange(N)+.5)*dx,H,c,psi],delimiter=',',header='x,H,c,psi',comments='')
    return out

if __name__ == "__main__":
    print(json.dumps(run(Path.cwd()),ensure_ascii=False,indent=2))
