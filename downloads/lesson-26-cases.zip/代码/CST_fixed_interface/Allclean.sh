#!/bin/sh
rm -f log.CST cst_result.json cst_equilibrium.csv
