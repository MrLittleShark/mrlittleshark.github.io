# 固定界面一维 CST 参考

本算例是独立的 Python 有限体积验证，依赖 numpy。进入本目录执行 `./Allrun.sh`。参数全部写在 CST.py 中。

左半域 H=0.2、D=1，右半域 H=1、D=4。c=H*psi，外端无通量。积分方程为 H*dpsi/dt=div(D*H*grad(psi))。使用隐式 Euler 与三对角消元，160 个单元，时间步 0.0005，运行 2000 步。

输出 cst_equilibrium.csv 和 cst_result.json。检验总量误差小于 1e-8，平衡浓度比接近 0.2。界面固定，不包含 VOF、反应或移动界面质量源。
