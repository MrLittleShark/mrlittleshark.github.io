# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`iso_growth_geometricInit`。参数对照和基础验证分别见以下独立目录。

- [injection_N24_theta90](injection_N24_theta90/README.md)
- [injection_N32_theta90](injection_N32_theta90/README.md)
- [injection_N48_theta90](injection_N48_theta90/README.md)
- [Faraday_flux_1D](Faraday_flux_1D/README.md)
- [Faraday_flux_wedge](Faraday_flux_wedge/README.md)
- [injection_growth](injection_growth/README.md)
- [iso_growth_uniform90](iso_growth_uniform90/README.md)
- [iso_growth_wettingBands](iso_growth_wettingBands/README.md)
- [iso_growth_geometricInit](iso_growth_geometricInit/README.md)
- [CST_fixed_interface](CST_fixed_interface/README.md)：固定界面分配与守恒验证。
