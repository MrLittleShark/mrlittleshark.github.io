# 几何VOF附着气泡：iso_growth_uniform90

本例比较初始化与润湿边界对附着气泡增长的影响。

## 计算问题与几何

计算域为5°轴对称楔形域，轴向为y，径向坐标为r。外半径4 mm，总高度8 mm。底部中心圆孔半径0.25 mm，内环为0.25–0.55 mm，外环为0.55–1 mm，外围基底为1–4 mm。几何和润湿条件均绕轴保持不变，因此可以使用楔形模型；单方向横流会破坏这一对称条件，需另建三维计算域。

网格沿径向依次布置4、6、9、24个单元。轴向下部0–2 mm布置40层，上部2–8 mm布置40层，共3440个单元。近壁最小轴向尺寸为50 μm。初始球面半径0.4 mm、球心位于原点，域内部分构成半球。初场几何角为气侧90°。分区润湿案例改变壁面约束后包含初始形状调整，应与随后持续注气共同分析。

气体从孔口以0.025 m/s进入，入口alpha.water为0。液体与气体密度分别为998和0.0838 kg/m³，运动黏度分别为1e-6和1.05e-4 m²/s，表面张力0.072 N/m。固体表面使用noSlip，顶面使用prghPressure和pressureInletOutletVelocity，允许液体排出。alpha.water顶面采用inletOutlet，反流时进入水；两侧面为wedge，退化轴面为empty。

## 物理尺度与离散设置

以孔径0.5 mm和入口速度计算，Re=Uin d/νl=12.5，Ca=μl Uin/σ≈3.47e-4，We=ρl Uin²d/σ≈4.33e-3。以初始球面半径0.4 mm计算，Bo=ΔρgR²/σ≈0.0218，毛细时间sqrt(ρlR³/σ)≈0.942 ms。当前条件下表面张力作用显著，30 ms对应约32个初始毛细时间。

求解器为本机v2512 interIsoFoam，界面采用isoAdvector输运、plicRDF重构。plicRDF通过重构距离函数获得界面法向，并在界面单元中构造分片平面；随后依据面被不同相占据的时空比例计算相通量。该过程与interFoam的代数MULES处理不同。fvSolution中的cAlpha保留为interfaceProperties所需读入条目，并不代表isoAdvector采用界面压缩通量。

时间离散为Euler，对流动量项采用Gauss upwind，压力校正3次，外循环1次。初始时间步1e-5 s，上限1e-5 s；maxCo=0.2、maxAlphaCo=0.15约束自适应时间步。Courant约束依赖速度和网格，不能代替毛细时间尺度检查。使用adjustableRunTime每2 ms保存一次，终点为30 ms。

## 运行与文件阅读

在已加载v2512环境的终端中进入当前算例，执行`./Allrun.sh`。脚本依次执行blockMesh、checkMesh、初始化命令和interIsoFoam，所有字典均位于本目录。blockMesh读取system/blockMeshDict；初始化工具写入0/alpha.water；求解器读取0、constant和system，并将场写入时间目录。日志中的“Selecting reconstructionScheme plicRDF”和“isoAdvection”用于确认实际算法。

```sh
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
interIsoFoam > log.interIsoFoam 2>&1
```

几何初始化案例的第三条命令为`setAlphaField > log.setAlphaField 2>&1`。随后读取孔口的alpha.water边界值，确认其为uniform 0，保证输入气体。查看图形时打开case.foam，在alpha.water上提取0.5等值线，并显示底部不同patch的位置。各参数组分别存放，比较时使用相同物理时刻。

## 本例设置与实际结果

本例内环theta0=90°，外环theta0=90°，外围基底90°。实际初始气体体积为1.4038084669e-10 m³；末时刻0.03 s的气体体积为2.8773654065e-10 m³，V0+Qt收支相对误差为4.048367e-08。两者均按当前网格实际体积统计。

末时刻壁面alpha.water=0.5的径向位置约0.496394 mm，轴向质心0.208776 mm。壁面位置由相邻边界面中心值线性插值得到，需结合50–125 μm量级的局部网格解释其精度。共享面连通性检查未检测到脱落。

本例使用sphereToCell按单元中心赋值，因此初始体积不等于精确半球体积。比较增长时使用离散V0；研究初始几何误差时再与2πR³/3比较。

最终保存场中，液相alpha>0.99区域的最大速度为0.201337 m/s，气相alpha<0.01区域为1.57678 m/s。低密度气相中的局部速度明显高于液相；该量不能解释为气泡上升速度。定量研究局部流动时还需检验毛细离散误差和网格分辨率。

## 复核与研究练习

1. 从网格读取孔口面积，用实际入口速度计算体积流量；与日志和体积增长比较。
2. 在独立目录中加密近接触线网格，并保持其余输入不变，比较壁面界面位置和液相速度。
3. 将最大时间步减半，比较同一物理时刻的体积、质心和边界电流；记录与当前结果的相对变化。
4. 保存修改后的字典、Allrun.sh、完整日志和原始场。

## 依据

求解器与工具实现依据本机OpenCFD v2512的interIsoFoam、isoAdvection、plicRDF、setAlphaField和有限体积电势离散源码。经典几何VOF方法背景：Roenby、Bredmose与Jasak（2016），A computational method for sharp interface advection，Royal Society Open Science，doi:10.1098/rsos.160405。本例新增导电—集气注气关系以随附源码和离散收支检查为准。
