# Faraday_flux_1D

第 26 讲：电极气泡_产气与生长。

## 算例用途

恒通量扩散：初始浓度为零，底部向域内注入标量，其余边界按 0/T 设置。D=4.5e-9 m2/s。一维例用半无限恒通量解析解检查；wedge 例使用局部通量面并包含径向扩散。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

本例 T 表示浓度，mol/m3，量纲由 dimensions 指定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
laplacianFoam > log.laplacianFoam 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `1` |
| system/controlDict | deltaT | `0.005` |
| system/controlDict | writeInterval | `1` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 4.5e-09` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |

实际网格：单元数 160。

## 文件与阅读顺序

- `0/T`：标量初值与边界，本例物理意义见上文。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

本例 endTime 与实际测试时长见上表和测试记录。长时算例可在课前完成，课堂演示使用已保存的时间序列。是否发生脱落或形成周期，按实际结果与判据判断。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 2.711 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/Faraday_flux_1D`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/21_Faraday通量与溶解气体/代码/constant_flux_1D。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：验证算例。保留，补充推导、定量定义和参数研究。

Faraday关系首先给出摩尔率，体积流量还取决于温度、绝对压力及气体收集假设。注气体积检查采用V0+积分Qdt，不能忽略初始气泡。固定界面分配模型与移动界面输运分别验证。

应量化的内容：Faraday换算、累计输入与体积收支、相间分配验证、注气与传质区别。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。

已有运行数据（指标定义见数值检查记录）：

- `surface_relative_error`：8.110063857991179e-05
- `inventory_relative_error`：1.0191847366058937e-13
