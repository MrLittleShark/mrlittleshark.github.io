#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setAlphaField > log.setAlphaField 2>&1
foamDictionary 0/alpha.water -entry boundaryField/gasInlet/value -value > log.inletPhase 2>&1
interIsoFoam > log.interIsoFoam 2>&1
touch case.foam
