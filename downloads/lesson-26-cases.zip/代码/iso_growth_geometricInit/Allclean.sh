#!/bin/sh
set -e
foamListTimes -rm
rm -rf constant/polyMesh postProcessing
rm -f log.* electroBalance.csv case.foam
