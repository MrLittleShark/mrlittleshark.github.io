# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`project_filter_porous`。参数对照和基础验证分别见以下独立目录。

- [project_cht_k0p1](project_cht_k0p1/README.md)
- [project_cht_k10](project_cht_k10/README.md)
- [project_filter_clean](project_filter_clean/README.md)
- [project_filter_porous](project_filter_porous/README.md)
