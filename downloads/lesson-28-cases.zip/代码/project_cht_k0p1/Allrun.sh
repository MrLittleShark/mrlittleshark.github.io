#!/bin/bash
set -e
blockMesh -region fluid > log.blockMesh.fluid 2>&1
blockMesh -region solid > log.blockMesh.solid 2>&1
checkMesh -region fluid > log.checkMesh.fluid 2>&1
checkMesh -region solid > log.checkMesh.solid 2>&1
chtMultiRegionSimpleFoam > log.chtMultiRegionSimpleFoam 2>&1
foamToVTK -region fluid -latestTime -ascii > log.foamToVTK.fluid 2>&1
foamToVTK -region solid -latestTime -ascii > log.foamToVTK.solid 2>&1
touch case.foam
