# 结课项目：project_cht_k0p1

本目录用于共轭传热项目。本次结果由第 28 讲当前目录的 Allrun.sh 独立运行获得。

## 结课项目：共轭传热与扩张过滤通道

### 项目组织和研究量

本讲提供两个工程问题、四个完整目录。project_cht_k0p1 与 project_cht_k10 构成材料导热率对照；project_filter_clean 与 project_filter_porous 构成清洁通道与多孔阻力对照。每个目录均保存本项目的初始场、物性、网格和算法字典，可在第 28 讲目录中直接运行。项目要求从模型方程出发，明确控制参数和目标量，再通过独立运行、守恒核算及参数对照形成报告。

传热项目以接口总热流和出口质量加权温度为主要目标量。过滤项目以给定流量下的压力差、阻力耗散和扩张后回流为主要目标量。两项研究都需要网格和数值参数检查，但积分对象不同：传热需要流体焓流与固体导热收支，过滤需要体积流量和动量阻力。不能只用一张场图代替这些量化检查。

### 项目一：固体导热率与流体侧热阻

空气通道长 0.10 m、高 0.01 m，底部固体板厚 0.002 m，计算厚度为 0.01 m。入口空气速度为 0.25 m/s、温度为 300 K，固体底面为 350 K；其余外部热边界为绝热。fluid 区域有 2560 单元，solid 区域有 640 单元，流固接触面两侧均为 80 个面。两个目录只改变固体导热率，分别为 0.1 和 10 W/(m·K)。

流体满足质量、动量和显热输运方程，固体满足稳态导热方程。理想接触要求 T_f=T_s，且两侧外法向导热通量之和为零。constant/regionProperties 声明区域，mappedWall 指定几何对应，温度耦合条件从 fluidThermo 和 solidThermo 读取材料导热信息。该问题没有接触热阻，界面温度不是事先给定的常数，而由两侧热阻共同决定。

先用 R_s''=δ_s/k_s 估计固体面热阻，分别得到 0.02 和 0.0002 m²·K/W。若只有固体导热，导热率增加会显著减小温差；在共轭问题中，流体侧热边界层仍限制总传热。按本项目重新运行的结果，接口传热量分别为 0.35322206 和 0.41108555 W，出口质量加权温度分别为 312.06159 和 313.89942 K。导热率增加 100 倍，传热量只增加约 16.382%。

守恒核查分三步进行。首先核对固体底面输入与固体界面放热，再比较两侧接口温度和带符号热流，最后检查流体进出口的显热与动能输运。低导热率项目的接口热流为 0.35322206 W，显热对流增加为 0.34937118 W，固定温度入口还存在净轴向导热 -0.00385027 W。将动能输运的小量变化一并计入后，流体能量相对不平衡约为 2.69e-08。这一步说明，出口热量与壁面热量之间的差额可能来自实际边界通量，而不一定是耦合错误。

两组均使用 chtMultiRegionSimpleFoam 完整执行 2000 次稳态迭代。项目扩展先固定材料和所有边界条件，分别细化流体近壁网格、固体厚度方向网格，比较总热流与出口温度。若同时改变材料和网格，就无法单独评价材料效应。增加接触热阻属于模型扩展，应另写温度跳跃与热流的关系，并建立独立目录验证。

### 项目二：扩张通道与多孔阻力

过滤通道总长 80 mm，入口段高 6 mm，在 x=20 mm 处扩张为 10 mm，厚度为 1 mm。滤层位于 x=35–45 mm，长度 10 mm。网格共 2880 单元，滤层区包含 400 单元。多孔算例先执行 blockMesh，再由 topoSet 根据几何范围选取滤层单元并创建 filterZone；清洁算例不添加区域阻力。两个目录均可从输入文件重新生成网格。

流体密度按 1000 kg/m³ 换算压力，运动黏度为 10⁻⁵ m²/s，入口速度为 0.1 m/s，入口高度对应 Re_H=60。入口体积流量为 6×10⁻⁷ m³/s，出口指定运动学压力零。两组几何和流量相同，清洁目录不启用阻力源项，多孔目录在 filterZone 内加入 Darcy–Forchheimer 阻力。

各向同性阻力可写为 S_U=−(μd+ρf|U|/2)U，其中 d 的单位为 m⁻²，f 的单位为 m⁻¹。本例 d=10⁸ m⁻²、f=1000 m⁻¹。先按滤层平均速度 U_m=Q/A≈0.06 m/s 估计压力差，Darcy 项约为 600.0000 Pa，Forchheimer 项约为 18.0000 Pa。这个估算忽略了非均匀速度、入口发展和扩张损失，适合核对数量级，不能替代完整控制方程。

本项目新运行结果中，清洁通道压力差为 10.859478 Pa，多孔通道为 621.843441 Pa，两者增加约 610.983963 Pa。通过在相同几何和流量下比较两组，能够更清楚地观察区域阻力的影响。滤层阻力耗散由 −∫S_U·U dV 计算，当前约为 0.00035895631 W；通道进出口压力功、动能通量变化和其他黏性耗散需要另行区分，不能把整个通道压力功都归入滤层。

两组均从初始场完整运行至 8 s，时间步为 0.002 s，共 4000 步。清洁和多孔项目的相对体积流量不平衡分别为 1e-12 和 6.17e-12。最后一秒的压力差变化用于判断监测量是否稳定，但时间步独立性还需要减半时间步后比较相同物理时刻。稳态监测量稳定与离散误差较小属于两项不同要求。

### 报告内容与评价

报告先说明几何、控制方程、材料或阻力参数及边界条件，再给出网格、离散格式、耦合算法和运行区间。结果部分至少包含一张真实场图、一张目标量对照图以及一张守恒表。图中注明变量、单位、坐标、时刻和数据目录；读取运动学压力时应写出乘密度换算为帕的步骤。

独立性研究应在完整副本中进行。传热项目重点检查区域网格和耦合迭代；过滤项目重点检查扩张区与滤层网格、时间步和阻力离散。三档网格或时间步的目标量可用于估算变化趋势和收敛阶，但需要保持其他输入一致。最终结论应回答材料或区域阻力如何影响目标量，并给出仍影响精度的具体因素。
## 本目录执行命令

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 完整内容：

```bash
#!/bin/bash
set -e
blockMesh -region fluid > log.blockMesh.fluid 2>&1
blockMesh -region solid > log.blockMesh.solid 2>&1
checkMesh -region fluid > log.checkMesh.fluid 2>&1
checkMesh -region solid > log.checkMesh.solid 2>&1
chtMultiRegionSimpleFoam > log.chtMultiRegionSimpleFoam 2>&1
foamToVTK -region fluid -latestTime -ascii > log.foamToVTK.fluid 2>&1
foamToVTK -region solid -latestTime -ascii > log.foamToVTK.solid 2>&1
touch case.foam
```

## 当前目录数值记录

```json
{
  "case": "project_cht_k0p1",
  "lesson": 28,
  "final_time": 2000.0,
  "iteration_count": 2000,
  "solver": "chtMultiRegionSimpleFoam",
  "fluid_cells": 2560,
  "solid_cells": 640,
  "solid_kappa_W_m_K": 0.1,
  "fluid_T_min": 299.999993889,
  "fluid_T_max": 344.822423095,
  "solid_T_min": 324.375677965,
  "solid_T_max": 349.715500287,
  "outlet_mass_weighted_T_K": 312.0615929500886,
  "mass_in_kg_s": 2.8965591750939e-05,
  "mass_out_kg_s": 2.89655917870961e-05,
  "relative_mass_balance": 1.2482777015857173e-09,
  "interface_fluid_heat_W": 0.3532220601075,
  "interface_solid_heat_W": -0.3532220601075,
  "heater_input_W": 0.3532220607762,
  "interface_relative_heat_mismatch": 0.0,
  "solid_relative_energy_mismatch": 1.893143318412091e-09,
  "max_interface_temperature_jump_K": 0.0,
  "advective_enthalpy_increase_W": 0.34937117776127335,
  "advective_kinetic_energy_increase_W": 5.983456236722742e-07,
  "inlet_outlet_axial_conduction_W": -0.0038502745010815433,
  "fluid_energy_relative_mismatch": 2.6893907625772764e-08,
  "passed": true,
  "path": "28_结课项目/代码/project_cht_k0p1",
  "source_case": "cht_channel_k0p1"
}
```

完整记录位于本讲 `测试结果/project_cht_k0p1`，包括本目录的实际退出码、输入指纹、执行脚本与日志。
