#!/bin/sh
set -e

foamListTimes -rm -noZero
rm -rf constant/fluid/polyMesh constant/solid/polyMesh processor[0-9]* processors[0-9]* postProcessing VTK
rm -f log.* case.foam
