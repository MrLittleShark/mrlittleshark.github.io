# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [constant_flux_1D](constant_flux_1D/README.md)
- [axisymmetric_wedge](axisymmetric_wedge/README.md)
