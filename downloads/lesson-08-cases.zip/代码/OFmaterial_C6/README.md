# OFmaterial_C6

第 8 讲：blockMesh与轴对称。

## 算例用途

纯网格练习：轴对称楔形、单块立方体、方腔分块或圆管分块，当前类型由目录名和 blockMeshDict 明确给出。 本例不执行流场求解。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| constant/transportProperties | nu | `nu [ 0 2 -1 0 0 0 0 ] 0.01` |
| system/fvSolution | nCorrectors | `1` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |
| system/decomposeParDict | numberOfSubdomains | `4` |

实际网格：单元数 216000。

## 文件与阅读顺序

- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/decomposeParDict`：并行分区。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

先由vertices和hex顶点顺序确定块的局部方向，再计算各方向单元数。simpleGrading给出整个块末端与起始端的单元尺寸比；它不是相邻单元的增长比。

多块网格应检查共享面的顶点、单元数量及分布是否相容。外部patch面法向应朝域外，内部共享面保持内部连接，不应误设为壁面。本目录为多块圆管，共216000个单元，可用于分析弧边、径向分辨率与块间连接；当前脚本只生成和检查网格。

二维empty与轴对称wedge采用不同几何约束。前者的积分包含薄层厚度，后者的积分包含楔角；5°轴对称全周体积约为楔形积分72倍，质心是积分之比，不需乘72。

本例用于验证几何尺寸与拓扑，不执行流场求解。研究训练需进一步报告最小尺度、局部加密方向及其与边界层或扩散层厚度的关系，并把生成网格用于后续守恒与压降分析。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 7.499 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/OFmaterial_C6`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/OF_material/101BLOCKMESH/C6。当前目录按 v2512 运行并重写说明；原始资料未修改。
