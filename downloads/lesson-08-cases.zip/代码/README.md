# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [axisymmetric](axisymmetric/README.md)
- [OFmaterial_C1](OFmaterial_C1/README.md)
- [OFmaterial_C2](OFmaterial_C2/README.md)
- [OFmaterial_C6](OFmaterial_C6/README.md)
