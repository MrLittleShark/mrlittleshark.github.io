#!/bin/sh
set -e

foamListTimes -rm
rm -rf constant/polyMesh
rm -f log.* case.foam
