#!/bin/sh
set -e

foamListTimes -rm -noZero
rm -rf constant/polyMesh processor[0-9]* processors[0-9]* postProcessing VTK
rm -f log.* case.foam
