#!/bin/sh
set -e
blockMesh > log.blockMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh 2>&1
pimpleFoam > log.pimpleFoam 2>&1
postProcess -func writeCellCentres -latestTime > log.cellCentres 2>&1
postProcess -func writeCellVolumes -latestTime > log.cellVolumes 2>&1
touch case.foam
