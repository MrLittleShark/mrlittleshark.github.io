# icoFoam

第 14 讲：压力速度耦合。

## 算例用途

本例研究压力速度耦合中的通量修正和非线性更新。压力方程依据单元净通量建立，修正后的 phi 应满足离散连续性；线性求解器的迭代次数与 PIMPLE 外循环次数分别统计。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.001` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 3.122 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/icoFoam`。测试参数与计算时段见运行记录。

## 定量分析与后续验证

当前算例为 icoFoam，deltaT=0.001 s、endTime=0.1 s，实际保存至 0.1 s。保存场速度分量范围为 [-0.4178328, 0.7934201] m/s。本目录采用 PISO 流程，时间步为 0.001 s；与 pimpleFoam 的 0.005 s 不同。

pimple_outer1、pimpleFoam（outer2）和 pimple_outer4 保持时间步和格式相同，适合隔离外循环次数的作用。icoFoam 与 pimpleFoam 同时存在时间步、对流格式差异，不能将其最终场差异全部归因于 PISO 和 PIMPLE。进一步验证需固定算法设置开展三档时间步研究，比较连续性误差、场变化和总耗时。

## 来源

课程原有 v2512 独立算例。原始输入、Allrun.sh 及既有测试记录保留；本次补充模型说明、实际统计和后续对照要求。
