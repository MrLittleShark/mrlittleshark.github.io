# 扩张过滤通道：Darcy–Forchheimer阻力

本例为独立流动案例，包含完整几何、初始场、边界、数值格式与运行命令。

## 运行

在本机OpenFOAM v2512环境中进入本目录，执行：

```sh
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的命令如下：

```sh
#!/bin/sh
set -e
blockMesh > log.blockMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh 2>&1
topoSet > log.topoSet 2>&1
pimpleFoam > log.pimpleFoam 2>&1
postProcess -func writeCellCentres -latestTime > log.cellCentres 2>&1
postProcess -func writeCellVolumes -latestTime > log.cellVolumes 2>&1
touch case.foam
```

每条命令的日志保存在当前目录。修改参数时复制完整目录，保留原输入和结果，再运行新的参数组。使用ParaView打开case.foam；选择实际保存时刻并核对变量单位。

## 模型方程与几何

入口高6mm，在x=20mm扩张到10mm，出口x=80mm，厚度1mm，前后empty。ρ=1000kg/m³、ν=1e−5m²/s，入口速度0.1m/s，Re=60。壁面noSlip，出口p=0、U为零梯度。流量Q=6e−7m³/s。

连续性方程为∇·U=0，动量方程为∂U/∂t+∇·(UU)=−∇pₖ+ν∇²U+S；pₖ=p/ρ，单位m²/s²。压力换算为Pa时需乘1000kg/m³。

本目录S=−[νd+0.5f|U|]U，d=1e8m⁻²、f=1000m⁻¹。topoSet把x=35–45mm区域建立为filterZone，含400单元，体积1e−7m³。fvOptions按该cellZone加载DarcyForchheimer源项。该体平均模型不解析孔隙，也不包含颗粒沉积或吸附。

## 数值方法与运行时段

pimpleFoam采用backward时间离散，动量对流linearUpwind，PIMPLE外迭代2次、压力修正2次。Δt=0.002s，计算至8s，场每1s保存。网格2880单元，标准与扩展网格检查均通过。

## 实际结果与解释

最终入口—出口压差621.843441Pa，出口流量5.99999999996e-07m³/s，流量相对不平衡6.167e-12。最后一秒压降的相对变化4.197e-11，显示当前输入下时间变化已很小。

扩张后可见回流。以x>20mm且Ux<−1e−5m/s统计，当前有38个反向单元。该判据依赖网格，不能直接作为连续流场的精确分离线。比较回流需保留相同几何、网格、时刻和阈值。

以区内平均速度0.06m/s估算，Darcy压降约600Pa，Forchheimer约18Pa。实际全通道压降还包括壁面黏性、扩张和阻力界面效应。压力功率按ΔpQ估算；源项耗散只是完整机械能收支的一部分。

## 参数研究

先在固定流量下改变d、f和区域长度，再另建固定压差条件的试验。比较压降、流量、过滤区速度和源项功率，并加密阻力区前后界面。两种驱动条件不可混在同一组对比中。

## 测试与来源

本目录Allrun.sh已实际执行，退出码0。测试结果、脚本快照、数值检查和原始日志见本讲“测试结果/expanded_filter_porous”。运行时间取日志中的求解器ClockTime；网格案例取snappyHexMesh耗时，未将其写成完整课堂操作耗时。

独立构建扩张过滤通道；DarcyForchheimer 接口参考本机 pisoFoam/laminar/porousBlockage。
