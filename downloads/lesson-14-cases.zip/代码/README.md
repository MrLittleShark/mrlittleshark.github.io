# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`expanded_filter_porous`。参数对照和基础验证分别见以下独立目录。

- [icoFoam](icoFoam/README.md)
- [pimpleFoam](pimpleFoam/README.md)
- [pimple_outer1](pimple_outer1/README.md)
- [pimple_outer4](pimple_outer4/README.md)
- [expanded_filter_clean](expanded_filter_clean/README.md)
- [expanded_filter_porous](expanded_filter_porous/README.md)
