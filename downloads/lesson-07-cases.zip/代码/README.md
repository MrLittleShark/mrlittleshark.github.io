# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [skew0](skew0/README.md)
- [skew0.025](skew0.025/README.md)
- [skew0.07](skew0.07/README.md)
