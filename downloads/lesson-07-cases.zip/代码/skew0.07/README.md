# skew0.07

第 7 讲：网格质量。

## 算例用途

顶盖驱动方腔：流体初始静止，顶盖沿 x 方向运动，其余侧壁静止。使用二维不可压缩层流模型，观察速度、压力与迭代过程。具体几何和物性见下表。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.0002` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `2` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

单元中心连线d与公共面面积向量Sf之间的夹角定义非正交角；面中心相对d与面交点的偏离用于定义偏斜度。应在实际局部网格上分别标出这两个几何量。

当前三组网格改变上边界水平偏移，计算域形状随之变化。因此，速度差异同时包含几何影响和网格影响，不能据此单独评价离散误差。

本讲旧速度比较沿固定拓扑列提取。倾斜网格中该列不是同一条竖直物理中线；跨算例定量比较应重新在相同物理坐标采样，并说明插值方法。

工程训练应固定边界几何，改变内部网格密度或扭曲程度，比较流量、压降或局部梯度。checkMesh通过只是必要检查，仍需用多组网格评估目标输出的变化。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 5.369 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/skew0.07`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/07_网格质量/代码/skew0.07。当前目录按 v2512 运行并重写说明；原始资料未修改。
