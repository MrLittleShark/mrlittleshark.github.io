# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [damBreak3D](damBreak3D/README.md)
- [rising_interFoam_N24_theta90](rising_interFoam_N24_theta90/README.md)
