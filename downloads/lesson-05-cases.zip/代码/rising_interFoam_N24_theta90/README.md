# rising_interFoam_N24_theta90

第 5 讲：三维溃坝与上升气泡。

## 算例用途

轴对称气泡：使用 5 度 wedge 表示完整旋转体。alpha.water=1 为水，0 为气体。初始区域由本目录的 alpha.water 或 setFieldsDict 指定，重力由 constant/g 给出。产气源为零，分析初始气泡的界面演化、压力平衡或运动过程。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

两相介质为水和空气，初始气泡由相分数场给定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
interFoam > log.interFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `interFoam` |
| system/controlDict | endTime | `0.00015` |
| system/controlDict | deltaT | `2e-06` |
| system/controlDict | writeInterval | `1.4999999999999999e-05` |
| constant/transportProperties | nu | `1e-6` |
| constant/transportProperties | sigma | `0.072` |
| 0/alpha.water | theta0 | `90` |
| system/fvSolution | nCorrectors | `3` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 1152。

## 文件与阅读顺序

- `0/p_rgh`：去除重力静压后的压力，单位 Pa。
- `0/U`：速度初值和各边界，单位 m/s。
- `0/alpha.water`：水体积分数初值与接触角或回流条件。
- `constant/g`：重力方向与大小。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/setFieldsDict`：当前算例的输入文件，具体设置见文件注释。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

VOF 方法以 αwater 描述水占单元体积的比例，水体积为Σαwater V，气体体积为Σ(1−αwater)V。初始化后先核对离散体积、重力方向及开放边界，避免将几何设定体积直接当作离散体积。

对于开放边界，体积变化必须与相通量共同分析；只检查体积相对变化可能把真实流出误判为质量损失。接触角、回流相和压力边界需与实际外部介质一致。

界面可用 αwater=0.5 等值面显示，同时检查0≤αwater≤1和保存时刻。局部最大速度、气泡质心速度和波前推进速度是不同统计量，应分别计算。本目录仅计算0.00015s，气泡质心变化约0.219μm，不能由此测得终端上升速度。

本讲承担界面初始化与守恒分析。面向研究训练，应进一步引入 interFoam/interIsoFoam 对照、界面分辨率和时间步研究，使用可测量的界面位置或质心轨迹评价差异。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 5.252 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/rising_interFoam_N24_theta90`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/05_三维溃坝与上升气泡/代码/rising__interFoam_N24_theta90。当前目录按 v2512 运行并重写说明；原始资料未修改。
