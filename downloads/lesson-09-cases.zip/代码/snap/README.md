# snap

第 9 讲：snappyHexMesh原理。

## 算例用途

为带凸起表面生成外部流体网格，当前目录对应切割细化、贴体或加层阶段。 本例不执行流场求解。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
surfaceCheck constant/triSurface/posts.stl > log.surfaceCheck 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh > log.checkMesh.2 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.001` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 1.0` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |
| system/snappyHexMeshDict | nSurfaceLayers | `2` |
| system/snappyHexMeshDict | finalLayerThickness | `0.3` |
| system/snappyHexMeshDict | expansionRatio | `1.2` |

实际网格：单元数 9066。

## 文件与阅读顺序

- `0/pointLevel`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `0/cellLevel`：网格生成后写出的诊断字段，用于检查实际细化或层生成情况。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `constant/triSurface/posts.vtp`：当前算例的输入文件，具体设置见文件注释。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/snappyHexMeshDict`：当前算例的输入文件，具体设置见文件注释。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

STL描述固体边界表面，blockMesh给出覆盖目标区域的背景体网格。先核对两者尺寸，再检查表面闭合、法向和特征边；表面三角片数不能直接当作体网格分辨率。

castellatedMesh调整拓扑与细化等级，snap移动边界点，addLayers增加近壁层单元。每阶段使用独立目录，按相同截面检查边界位置和最小尺度。

locationInMesh必须位于所需流体连通区域内部。对本例圆柱凸起，既要检查柱顶和柱侧几何，也要检查柱间流道是否保留；选点错误可能使区域保留方向发生改变。

旧layers虽然执行结束，却没有生成壁面层。第10讲新成功例将绝对面锥体积阈值调整到毫米网格适用范围，并用层数分布、覆盖率及扩展质量检查验证；本讲保留旧结果用于解释阶段开关与实际效果的区别。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 5.203 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/snap`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/09_snappyHexMesh原理/代码/snap。当前目录按 v2512 运行并重写说明；原始资料未修改。
