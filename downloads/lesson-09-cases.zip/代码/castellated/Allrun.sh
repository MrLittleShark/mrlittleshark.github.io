#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
surfaceCheck constant/triSurface/posts.stl > log.surfaceCheck 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh > log.checkMesh.2 2>&1
touch case.foam
