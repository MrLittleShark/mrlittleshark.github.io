# Re100

第 6 讲：圆柱绕流。

## 算例用途

Re=100 圆柱绕流：D=1 m、Uinf=1 m/s、nu=0.01 m2/s，前后 empty，圆柱无滑移。pimpleFoam 采用层流模型，记录尾流及 forceCoeffs；Aref=0.1 m2。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
pimpleFoam > log.pimpleFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `pimpleFoam` |
| system/controlDict | endTime | `120` |
| system/controlDict | deltaT | `0.01` |
| system/controlDict | writeInterval | `5` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.01` |
| system/fvSolution | nOuterCorrectors | `2` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 1008。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

本例 endTime 与实际测试时长见上表和测试记录。长时算例可在课前完成，课堂演示使用已保存的时间序列。是否发生脱落或形成周期，按实际结果与判据判断。

## 分析方法与训练要求

本例Re=100，阻力和升力由圆柱表面的压力及黏性载荷积分得到。二维厚度b=0.1m必须包含在参考面积Aref=Db=0.1m²内，否则力系数会产生固定倍数误差。

域为x∈[−5D,15D]、y∈[−5D,5D]。上下边界采用slip，圆柱noSlip，前后empty；初始横向速度0.001m/s用于扰动。应检查阻塞效应、下游长度与壁面径向分辨率。

计算步长0.01s，力系数每步记录，U和p每5s写出。周期判定应使用力系数高频记录，并排除启动阶段；当前曲线是否形成稳定交替脱落，应根据重复周期和振幅演化判断。

1008单元结果用于定义受力和观察尾流，不直接用作高精度St基准。后续建立至少三组周向/径向网格和两组下游长度，报告平均Cd、Cl均方根及周期数量；未出现稳定周期时不拟造脱落频率。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 88.841 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/Re100`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/06_圆柱绕流/代码/Re100。当前目录按 v2512 运行并重写说明；原始资料未修改。
