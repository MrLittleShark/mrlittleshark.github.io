# keyword

第 4 讲：日志与排错。

## 算例用途

顶盖驱动方腔：流体初始静止，顶盖沿 x 方向运动，其余侧壁静止。使用二维不可压缩层流模型，观察速度、压力与迭代过程。具体几何和物性见下表。

本目录是故障练习，预期求解器报错退出。线性求解器类型被设为 NOT_A_SOLVER，检查 fvSolution 的 solver 条目。 修复前后日志应分别保存。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.005` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

按初始化、时间推进、线性方程求解和结果写出区分运行阶段。Time 表示物理时间，线性残差反映代数方程求解，连续性误差反映离散通量收支，三者不能混用。

定位错误时保留错误前的上下文，核对 Case 路径与实际修改目录。记录最先发生的异常，避免把后续缺失结果文件当作最初原因。

故障修复应同时检查语法、量纲和模型定义。合法关键字并不必然适合所用方程；例如 solver 必须是本机已注册的线性求解器类型，并与矩阵性质相容。本目录具体故障是solver NOT_A_SOLVER，属于非法类型，不是关键字缺失。

每次只改一项直接相关输入，保存修改前后差异与日志，补充退出码、最终时刻和基本物理量检查。故障触发成功属于教学测试通过，不能解释为流场计算通过。

## 测试

本次测试状态：PASS；退出码 1；完整脚本耗时 3.018 s。故障例的非零退出是预期报错。

原始日志和数值检查保存在本讲 `测试结果/keyword`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/04_日志与排错/代码/keyword。当前目录按 v2512 运行并重写说明；原始资料未修改。
