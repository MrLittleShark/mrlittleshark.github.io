# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [baseline](baseline/README.md)
- [dimensions](dimensions/README.md)
- [keyword](keyword/README.md)
- [missing_file](missing_file/README.md)
- [patch](patch/README.md)
- [scheme](scheme/README.md)
