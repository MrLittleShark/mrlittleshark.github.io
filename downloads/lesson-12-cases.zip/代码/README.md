# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [limitedLinear_Co0.5](limitedLinear_Co0.5/README.md)
- [linearUpwind_Co0.5](linearUpwind_Co0.5/README.md)
- [linear_Co0.5](linear_Co0.5/README.md)
- [upwind_Co0.5](upwind_Co0.5/README.md)
- [vanLeer_Co0.5](vanLeer_Co0.5/README.md)
