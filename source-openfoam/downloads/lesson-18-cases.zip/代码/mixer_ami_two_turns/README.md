# 旋转搅拌槽 AMI 启动过程

## 工程算例：旋转搅拌槽的 AMI 动网格

### 几何和运动区域

搅拌槽包含半径 0.10 m 的外壁、半径 0.02 m 的轮毂、叶尖半径 0.05 m 的转子以及内伸至半径 0.07 m 的定子挡板。半径 0.06 m 处设置滑动接口。原始网格由官方 mixerVesselAMI2D 教程生成，当前目录已保存展开后的 blockMeshDict，不需要课堂执行 m4 宏。网格共 3072 个单元，厚度为 0.01 m，前后面为 empty。

constant/dynamicMeshDict 指定 dynamicMotionSolverFvMesh、solidBody 运动求解器和 rotor 单元区。转轴为 z 轴，原点为 (0 0 0)，角速度 Ω=2π rad/s。每个时间步仅旋转 rotor 内的网格点，外部区域保持静止。U 的 rotor 边界采用 movingWallVelocity，从真实网格运动得到壁面速度；stator 虽采用同一边界类型，但其网格不移动，因此速度为零。

### AMI 的作用与守恒检查

AMI1 与 AMI2 是互相对应的 cyclicAMI 边界。两侧面不必一一匹配，插值权重由当前交叠几何计算，用于交换场值与离散耦合信息。AMI 不等同于 processor 接口：processor 由并行分区产生，而本例 AMI 来自两个具有相对运动的网格区域，即使串行运行也存在。

本次全部更新中，权重和最小值约为 0.9999999868，最大值约为 1.0002677780。接近 1 说明覆盖关系基本完整，但不能单独证明动量和能量的误差足够小。还应检查修正后的连续性误差、压力场、速度极值及转子力矩。本次最后一次压力修正后的局部连续性指标约为 2.82×10⁻⁹、全局指标约为 1.32×10⁻¹⁷；日志中还包含网格更新后的中间通量调整，应区分预测与修正后的记录。

### 黏性流动与时间分辨率

本例采用层流牛顿流体，运动黏度 ν=0.001 m²/s。搅拌工程常用 Re_N=ND²/ν，以每秒转数 N=1 s⁻¹、叶轮直径 D=0.10 m 得到 Re_N=10。该模型研究高黏度条件下的启动搅拌，不用于表示工业高雷诺数湍流混合，也没有加入多相界面。

时间格式为隐式 Euler，采用 PIMPLE 外循环和压力修正。初始时间步为 0.001 s，自动时间步受 maxCo=0.5 和 maxDeltaT=0.002 s 限制；最大一步转角不超过 0.72°。结果每 0.125 s 保存一次，对应 45° 的运动相位。计算从静止流场运行至 2 s，共两整周，不能以保存时刻数代替实际求解时间步数。

### 运动、力矩和启动响应

从旋转区域内同一网格点逐时读取坐标并展开极角，得到总转角 720.000000°；与 Ωt 的最大角度差约为 1.27e-14°。这一检查验证旋转对象、方向和时间，而不仅检查 dynamicMeshDict 是否含有 rotatingMotion。

终止时刻的最大速度为 1.06448 m/s，流体动能约为 0.00392599 J。forces 函数对 rotor 边界积分，使用密度 1000 kg/m³ 将运动学压力和黏性应力换算为力矩；最终 z 向流体力矩为 0.00396596 N·m。该值为流体作用于转子的瞬时力矩，不能直接当作电机所需平均轴功率。以相反符号计算 −ΩM_z 并沿已记录时段积分，转子向流体输入的净功约为 0.0220656 J。

图中保留启动阶段较强的速度和力矩波动，统一色标覆盖实际极值。当前两周结果用于检查动网格耦合和启动响应，不据此宣称周期稳态已经建立。若目标是平均搅拌功率，需要先固定网格，将最大时间步减半并收紧压力修正容差，比较相同角度下的力矩和速度，再延长计算检查相邻周期是否重复。最后才计算周期平均功率及其网格敏感性。

### 运行与后处理

进入代码/mixer_ami_two_turns 后执行 ./Allrun.sh。blockMesh 直接生成带 rotor 单元区的网格；pimpleFoam 完成真实运动；checkMesh -latestTime 检查最终网格；后处理保存速度大小和多个相位的 VTK 文件。ParaView 中先显示网格边线及 AMI 圆周，再比较同一色标下的速度场，可直接观察转子、定子与接口之间的相对运动。

## 本目录运行

先加载环境，再在本目录执行：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

本目录 Allrun.sh：

```bash
#!/bin/bash
set -e
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
pimpleFoam > log.pimpleFoam 2>&1
checkMesh -latestTime > log.checkMesh.final 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
foamToVTK -time 0.125,0.25,0.5,1,1.5,2 -ascii > log.foamToVTK 2>&1
touch case.foam
```

## 本次测试结果

完整运行记录位于本讲 `测试结果/mixer_ami_two_turns`，包含退出码、参数指纹、执行脚本和原始日志。数值检查结果如下：

```json
{
  "case": "mixer_ami_two_turns",
  "lesson": 18,
  "solver": "pimpleFoam / dynamicMotionSolverFvMesh",
  "final_time": 2.0,
  "rotation_rate_rad_s": 6.283185307179586,
  "period_s": 1,
  "completed_turns": 2.0,
  "maximum_rotation_angle_error_degree": 1.2722218725854067e-14,
  "cells": 3072,
  "kinematic_viscosity_m2_s": 0.001,
  "impeller_diameter_m": 0.1,
  "impeller_speed_rev_s": 1,
  "mixer_Re_ND2_nu": 10,
  "maximum_speed_m_s": 1.064478288459149,
  "kinetic_energy_final_J": 0.003925992073104461,
  "final_rotor_moment_z_Nm": 0.0039659606274,
  "AMI_weight_min": 0.9999999868,
  "AMI_weight_max": 1.000267778,
  "velocity_initial_to_final": "initial zero, two full revolutions of transient viscous mixing; periodic convergence not assumed",
  "rotor_work_input_J": 0.022065635232621623,
  "mean_second_cycle_moment_z_Nm": 0.0013623435577758624,
  "passed": true
}
```

## 文件阅读顺序

先读 system/blockMeshDict（多区域使用 system/fluid 与 system/solid），再读 0 中的场条件、constant 中的模型与物性，最后核对 fvSchemes、fvSolution 和 controlDict。全部输入位于当前目录，运行不依赖其他课次。
