#!/bin/bash
set -e
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
pimpleFoam > log.pimpleFoam 2>&1
checkMesh -latestTime > log.checkMesh.final 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
foamToVTK -time 0.125,0.25,0.5,1,1.5,2 -ascii > log.foamToVTK 2>&1
touch case.foam
