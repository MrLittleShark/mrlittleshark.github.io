#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
decomposePar > log.decomposePar 2>&1
mpirun -np 2 icoFoam -parallel > log.parallel 2>&1
reconstructPar -latestTime > log.reconstructPar 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
