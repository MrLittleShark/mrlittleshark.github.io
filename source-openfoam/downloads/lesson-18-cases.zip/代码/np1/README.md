# np1

第 18 讲：并行计算。

## 算例用途

本例在相同 400 单元方腔上采用 1 个串行进程，验证网格分解、内部接口通信和结果重构。processor 边界连接原来的相邻单元，不能当作新增物理壁面处理。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
icoFoam > log.icoFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `icoFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.005` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | nu | `[0 2 -1 0 0 0 0] 0.001` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |
| system/decomposeParDict | numberOfSubdomains | `1` |

实际网格：单元数 400。

## 文件与阅读顺序

- `0/p`：压力初值、边界与参考，单位应按求解器定义核对。
- `0/U`：速度初值和各边界，单位 m/s。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/decomposeParDict`：并行分区。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 2.966 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/np1`。测试参数与计算时段见运行记录。

## 定量分析与后续验证

当前 deltaT=0.005 s、endTime=0.1 s，实际重构结果至 0.1 s。速度分量范围为 [-0.4152182, 0.7912952] m/s。串并行比较必须在同一物理时刻、同一网格单元顺序和压力参考下进行。

与 np1、np2、np4、np8 比较重构速度的相对 L2 差异，另将求解耗时和包含分区、重构的流程耗时分开统计。400 单元的问题规模适合说明通信开销，不足以评估生产计算的可扩展性。新增 mixer_ami_two_turns 用真实旋转网格说明另一类接口耦合；AMI 插值接口与 processor 通信接口的作用不同。

## 来源

课程原有 v2512 独立算例。原始输入、Allrun.sh 及既有测试记录保留；本次补充模型说明、实际统计和后续对照要求。
