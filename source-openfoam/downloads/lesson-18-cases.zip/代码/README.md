# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`mixer_ami_two_turns`。参数对照和基础验证分别见以下独立目录。

- [np1](np1/README.md)
- [np2](np2/README.md)
- [np4](np4/README.md)
- [np8](np8/README.md)
- [mixer_ami_two_turns](mixer_ami_two_turns/README.md)
