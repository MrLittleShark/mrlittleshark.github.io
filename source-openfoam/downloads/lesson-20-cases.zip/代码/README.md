# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`vortex_plicRDF_N64`。参数对照和基础验证分别见以下独立目录。

- [interFoam_N24_theta120](interFoam_N24_theta120/README.md)
- [interFoam_N24_theta60](interFoam_N24_theta60/README.md)
- [interFoam_N24_theta90](interFoam_N24_theta90/README.md)
- [vortex_MULES_N64](vortex_MULES_N64/README.md)
- [vortex_isoAlpha_N64](vortex_isoAlpha_N64/README.md)
- [vortex_plicRDF_N64](vortex_plicRDF_N64/README.md)
- [vortex_plicRDF_N128](vortex_plicRDF_N128/README.md)
