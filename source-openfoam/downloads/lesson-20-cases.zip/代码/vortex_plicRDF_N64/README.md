# 可逆涡流界面输运：plicRDF，64×64

本例在给定、无散的时变涡流中输运初始圆盘，经历拉伸和回卷，到 t=8 s 时精确界面应回到初始位置。用于隔离相分数输运误差，PIMPLE 中 frozenFlow=yes，未求解动量方程。

## 模型与运行

采用本地 setFlow 的 vortex2D 速度，幅值乘 cos(2πt/16)。计算域为 x-z 平面 1 m×1 m，empty 方向厚0.02 m。初始圆盘中心(0.5,0,0.75) m、半径0.15 m，setAlphaField按切割体积初始化。固定时间步0.002 s，完整计算至8 s，保存0、2、4、6、8 s。

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh依次生成网格、检查质量、初始化相分数并运行interIsoFoam。在0、4、8 s比较初态、最大形变和回卷；采用体积加权L1、总量漂移和0<alpha<1混合单元数评价结果。不能仅凭界面锐利程度判定精度。

plicRDF是本组界面方法。64网格三方法保持相同时间步和输入；128网格plicRDF将时间步减半，因此该组反映空间与时间同步加密后的整体误差。与纯空间阶次研究需保持时间误差足够小的条件区分。

## 参数研究

比较三种方法的质量守恒与形状恢复；分析最大拉伸时局部液膜厚度是否达到网格尺度。进一步在固定细网格上独立减小时间步，再进行网格收敛分析。实际误差、耗时和图像见本讲测试结果。

## 本次完整计算结果

本例完成完整周期或规定计算时段。各统计量直接来自实际保存场。

```json
{
  "L1_domain": 0.019828539821792748,
  "L1_relative_to_phase_volume": 0.28111871920157294,
  "phase_volume_initial_m3": 0.0014106879739712334,
  "phase_volume_final_m3": 0.0014106879739712304,
  "volume_relative_drift": -2.1094237467877974e-15,
  "alpha_min": -3.5778671692022e-18,
  "alpha_max": 1.0,
  "mixed_cells_final": 81,
  "end_time": 8.0,
  "cells": 4096
}
```

当前目录Allrun.sh：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setAlphaField > log.setAlphaField 2>&1
interIsoFoam > log.interIsoFoam 2>&1
touch case.foam
```
