# interFoam_N24_theta90

第 20 讲：VOF与接触角。

## 算例用途

轴对称气泡：使用 5 度 wedge 表示完整旋转体。alpha.water=1 为水，0 为气体。初始区域由本目录的 alpha.water 或 setFieldsDict 指定，重力由 constant/g 给出。产气源为零，分析初始气泡的界面演化、压力平衡或运动过程。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

两相介质为水和空气，初始气泡由相分数场给定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
interFoam > log.interFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `interFoam` |
| system/controlDict | endTime | `0.00015` |
| system/controlDict | deltaT | `2e-06` |
| system/controlDict | writeInterval | `1.4999999999999999e-05` |
| constant/transportProperties | nu | `1e-6` |
| constant/transportProperties | sigma | `0.072` |
| 0/alpha.water | theta0 | `90` |
| system/fvSolution | nCorrectors | `3` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 1152。

## 文件与阅读顺序

- `0/p_rgh`：去除重力静压后的压力，单位 Pa。
- `0/U`：速度初值和各边界，单位 m/s。
- `0/alpha.water`：水体积分数初值与接触角或回流条件。
- `0/uniform/time`：当前算例的输入文件，具体设置见文件注释。
- `constant/g`：重力方向与大小。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/setFieldsDict`：当前算例的输入文件，具体设置见文件注释。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 17.398 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/interFoam_N24_theta90`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/20_VOF与接触角/代码/interFoam_N24_theta90。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：初始化与后处理诊断。保留作输入/指标验证；短时结果不作为平衡或动态润湿规律，主要分析转入新增长时及界面输运算例。

逐组核对theta0与初始几何thetaG，气相几何角和边界输入角满足补角关系。先计算初始离散体积，再比较后续漂移。短时界面图不能用于判定平衡接触角；同讲的完整可逆涡流用于单独评价界面输运误差。

应量化的内容：气液侧补角、初场离散体积、界面L1与守恒分别检查。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。

已有运行数据（指标定义见数值检查记录）：

- `end_time`：0.00015
- `initial_gas_volume`：2.583272455422624e-10
- `final_gas_volume`：2.5832724594876743e-10
- `gas_volume_drift`：1.5736049760744199e-09
