# coded_linear_robin

第 24 讲：codeStream与coded边界。

## 算例用途

无量纲平板标量的线性 Robin 验证。codedMixed 根据实际壁面距离计算 beta，D=1、h=1000，参考值 0.01，理论通量为 5。与第 22 讲 mixed 对照。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

本例 T 表示无量纲标量，量纲由 dimensions 指定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
laplacianFoam > log.laplacianFoam 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `30` |
| system/controlDict | deltaT | `1` |
| system/controlDict | writeInterval | `30` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 1` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |

实际网格：单元数 480。

## 文件与阅读顺序

- `0/T`：标量初值与边界，本例物理意义见上文。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 16.852 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/coded_linear_robin`。测试参数与计算时段见运行记录。

## 来源

新建：线性 codedMixed 对照。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：验证算例。保留，补充推导、定量定义和参数研究。

运行时编译应检验变量读取、量纲及每个边界面的距离。时间表的线性插值将改变脉冲面积，应以实际表函数积分核对域内总量，而非只比较脉冲峰值。

应量化的内容：运行时编译接口、解析边界和分段时间通量积分。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。

已有运行数据（指标定义见数值检查记录）：

- `boundary_flux`：5.0
