# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [codeStream__interFoam_N24_theta90](codeStream__interFoam_N24_theta90/README.md)
- [pulse_flux](pulse_flux/README.md)
- [coded_linear_robin](coded_linear_robin/README.md)
