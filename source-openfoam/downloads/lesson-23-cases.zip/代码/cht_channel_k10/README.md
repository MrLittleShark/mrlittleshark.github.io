# 受热通道共轭传热：固体导热率 10 W/(m·K)

## 工程算例：受热通道中的流固共轭传热

### 双区域模型和控制方程

空气沿长 0.10 m、高 0.01 m 的通道流动，底部为厚 0.002 m 的固体板，计算厚度为 0.01 m。固体底面保持 350 K，空气入口为 300 K、0.25 m/s，其余外部固体边界和通道上壁绝热。fluid 区域求解质量、动量和显热方程；solid 区域只求解导热方程。两侧各有独立的网格、热物性、初始场和求解设置。

流体显热输运包含对流和扩散，固体稳态导热满足 ∇·(k_s∇T_s)=0。无接触热阻的理想界面满足 T_f=T_s，且 k_f∂T_f/∂n_f+k_s∂T_s/∂n_s=0，两侧外法向方向相反。该界面同时求得壁温和热流，不能把流体壁温和壁面热通量都另外指定为独立定值。

### 区域映射与材料参数

constant/regionProperties 声明 fluid(fluid) 和 solid(solid)。两个区域的 blockMeshDict 都把 interface 定义为 mappedWall，sampleRegion 指向另一侧，samplePatch 同为 interface。温度使用 compressible::turbulentTemperatureRadCoupledMixed：流体的 kappaMethod 为 fluidThermo，固体为 solidThermo；qr 和 qrNbr 均为 none，辐射关闭。类型名称包含 turbulent 和 Rad，但本例实际采用层流、无辐射物理模型。

空气采用恒定比热 Cp=1000 J/(kg·K)、动力黏度 μ=1.8×10⁻⁵ Pa·s、Pr=0.7，因而 k_f=μCp/Pr≈0.0257143 W/(m·K)。密度由 perfectGas 状态方程随温度变化，不能仅按入口速度乘固定密度计算所有出口收支。重力设为零，当前案例为强迫对流。固体采用恒定各向同性导热率，两个目录分别为 0.1 和 10 W/(m·K)，其余输入保持一致。

### 网格、耦合和热阻估算

流体网格为 80×32×1，共 2560 单元；固体为 80×8×1，共 640 单元。流体 y 方向向两侧壁面加密，接口每侧均有 80 个面。两侧长度和面划分一致，适合检查最基本的区域耦合；非匹配接口应另建网格对照，而不能由当前结果直接推广。

固体面热阻可先估计为 R_s''=δ_s/k_s，两个材料分别为 0.02 和 0.0002 m²·K/W。实际总传热还受到流体热边界层和轴向导热影响。提高导热率会减小固体内部温差，但当主要热阻转移到流体侧后，传热量不会按 k_s 的倍数增长。该估算用于预判趋势，定量值由耦合方程计算。

### 完整计算和热量收支

两个算例均采用 chtMultiRegionSimpleFoam，完整执行 2000 次稳态迭代。区域内各自设置 fvSchemes 和 fvSolution，流体使用压力速度耦合与显热输运，固体使用导热求解。输出的 wallHeatFlux 采用进入相应区域为正的约定，因此同一界面的流体吸热与固体放热应一正一负。

k_s=0.1 W/(m·K) 时，固体加热面输入 0.35322206 W，流体接口吸热 0.35322206 W，出口质量加权温度为 312.06159 K。k_s=10 W/(m·K) 时，对应加热输入 0.41108555 W、接口吸热 0.41108555 W、出口温度 313.89942 K。传热量增加约 16.382%，小于材料导热率的增幅，反映了串联热阻的共同作用。

低导热率算例的进出口质量相对不平衡为 1.25e-09，固体外边界能量相对不平衡约 1.89e-09，流固接口温差在当前写出精度下为零。出口对流显热增加 0.34937118 W，并不与接口热量完全相等，因为入口固定温度边界还存在约 -0.00385027 W 的净轴向导热。把这项和动能输运变化计入后，流体能量相对误差约为 2.69e-08。忽略入口导热会把真实边界传热误判为耦合不守恒。

### 独立运行和参数研究

进入任一 cht_channel 目录后运行 ./Allrun.sh。脚本明确列出 blockMesh -region fluid、blockMesh -region solid 和两次区域 checkMesh，然后调用 chtMultiRegionSimpleFoam，最后分别导出 fluid 与 solid 结果。初始场位于 0/fluid 和 0/solid；固体热力学还读取压力场，因此该文件同样保留于目录中。

后续研究可保持几何和材料不变，分别细化流体近壁网格与固体厚度方向网格，比较接口热流及出口温度。若研究接触热阻，应在新目录中使用具有明确热阻参数的耦合条件，并验证界面温度跳跃与热流之间的关系；当前理想接触案例的温度连续性不再适用于该情形。结果报告需区分迭代误差、网格误差和材料参数影响。

## 本目录运行

先加载环境，再在本目录执行：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

本目录 Allrun.sh：

```bash
#!/bin/bash
set -e
blockMesh -region fluid > log.blockMesh.fluid 2>&1
blockMesh -region solid > log.blockMesh.solid 2>&1
checkMesh -region fluid > log.checkMesh.fluid 2>&1
checkMesh -region solid > log.checkMesh.solid 2>&1
chtMultiRegionSimpleFoam > log.chtMultiRegionSimpleFoam 2>&1
foamToVTK -region fluid -latestTime -ascii > log.foamToVTK.fluid 2>&1
foamToVTK -region solid -latestTime -ascii > log.foamToVTK.solid 2>&1
touch case.foam
```

## 本次测试结果

完整运行记录位于本讲 `测试结果/cht_channel_k10`，包含退出码、参数指纹、执行脚本和原始日志。数值检查结果如下：

```json
{
  "case": "cht_channel_k10",
  "lesson": 23,
  "final_time": 2000.0,
  "iteration_count": 2000,
  "solver": "chtMultiRegionSimpleFoam",
  "fluid_cells": 2560,
  "solid_cells": 640,
  "solid_kappa_W_m_K": 10.0,
  "fluid_T_min": 299.999994182,
  "fluid_T_max": 349.290792474,
  "solid_T_min": 349.475551768,
  "solid_T_max": 349.997015003,
  "outlet_mass_weighted_T_K": 313.89941776423643,
  "mass_in_kg_s": 2.8965592040159e-05,
  "mass_out_kg_s": 2.8965592012645203e-05,
  "relative_mass_balance": 9.498786868577886e-10,
  "interface_fluid_heat_W": 0.4110855498903,
  "interface_solid_heat_W": -0.4110855498903,
  "heater_input_W": 0.4110855477766,
  "interface_relative_heat_mismatch": 0.0,
  "solid_relative_energy_mismatch": 5.1417521346686054e-09,
  "max_interface_temperature_jump_K": 0.0,
  "advective_enthalpy_increase_W": 0.40260486412128577,
  "advective_kinetic_energy_increase_W": 6.1589785204433e-07,
  "inlet_outlet_axial_conduction_W": -0.008480081983152319,
  "fluid_energy_relative_mismatch": 2.94634295585766e-08,
  "passed": true
}
```

## 文件阅读顺序

先读 system/blockMeshDict（多区域使用 system/fluid 与 system/solid），再读 0 中的场条件、constant 中的模型与物性，最后核对 fvSchemes、fvSolution 和 controlDict。全部输入位于当前目录，运行不依赖其他课次。
