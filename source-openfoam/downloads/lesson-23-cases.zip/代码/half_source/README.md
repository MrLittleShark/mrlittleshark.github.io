# half_source

第 23 讲：源项与自适应加密。

## 算例用途

局部热源流动：初始温度 300 K，在 hotZone 施加温度方程源。基准温升源为 10 K/s，half_source 为 5 K/s，zero_source 为 0。使用 buoyantBoussinesqPimpleFoam 观察温度与速度响应。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

本例 T 表示温度，K，量纲由 dimensions 指定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
topoSet > log.topoSet 2>&1
buoyantBoussinesqPimpleFoam > log.buoyantBoussinesqPimpleFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `buoyantBoussinesqPimpleFoam` |
| system/controlDict | endTime | `0.2` |
| system/controlDict | deltaT | `0.002` |
| system/controlDict | writeInterval | `0.02` |
| constant/transportProperties | nu | `1e-6` |
| system/fvSolution | nCorrectors | `2` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 600。

## 文件与阅读顺序

- `0/p_rgh`：Boussinesq 运动学压力变量，单位 m2/s2；减去 rhok*gh，rhok 为浮力密度比。
- `0/U`：速度初值和各边界，单位 m/s。
- `0/T`：标量初值与边界，本例物理意义见上文。
- `0/alphat`：当前算例的输入文件，具体设置见文件注释。
- `constant/g`：重力方向与大小。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `constant/fvOptions`：当前算例的输入文件，具体设置见文件注释。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。
- `system/topoSetDict`：几何选区。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 3.929 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/half_source`。测试参数与计算时段见运行记录。

## 来源

23_源项与自适应加密/代码/heated_zone，独立参数对照：T (5 0);。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：验证算例。保留，补充推导、定量定义和参数研究。

温度方程源项以K/s给出时，积分热功率需要乘rho*Cp及选区体积。自适应细化须检查体积及相分数映射守恒；新增单元数本身不是精度提高的证据。

应量化的内容：源项量纲、区域体积、热量与界面通量、自适应映射守恒。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。
