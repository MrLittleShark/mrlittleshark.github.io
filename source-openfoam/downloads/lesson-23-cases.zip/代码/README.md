# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`cht_channel_k10`。参数对照和基础验证分别见以下独立目录。

- [amr3D](amr3D/README.md)
- [heated_zone](heated_zone/README.md)
- [zero_source](zero_source/README.md)
- [half_source](half_source/README.md)
- [cht_channel_k0p1](cht_channel_k0p1/README.md)
- [cht_channel_k10](cht_channel_k10/README.md)
