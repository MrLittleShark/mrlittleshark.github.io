# split_boundary

第 11 讲：网格转换与边界分区。

## 算例用途

网格处理练习：gmsh_import 将当前 msh 文件转换为 OpenFOAM 网格；split_boundary 从底部选出局部面并创建独立 patch。 本例不执行流场求解。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
topoSet > log.topoSet 2>&1
createPatch -overwrite > log.createPatch 2>&1
renumberMesh -overwrite > log.renumberMesh 2>&1
checkMesh > log.checkMesh.2 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `0.1` |
| system/controlDict | deltaT | `0.001` |
| system/controlDict | writeInterval | `0.1` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 1.0` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |

实际网格：单元数 1728。

## 文件与阅读顺序

- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/createPatchDict`：由选区创建边界。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。
- `system/topoSetDict`：几何选区。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 分析方法与训练要求

网格转换必须检查长度单位、单元类型、物理组名称及面法向。gmshToFoam执行完成后，应将转换前后的边界名称、面数和包围盒逐项核对。

faceSet用于选取面，cellSet用于选取单元，cellZone是供模型或源项引用的体区域；三者不应混用。第14讲多孔阻力必须引用cellZone，而入口与壁面边界使用patch。本例sourceWall为48面，剩余bottom为96面；surface选区与96个体单元的sourceZone分别核对。

createPatch改变边界分区，renumberMesh改变编号。重编号后继续使用编号列表时须重新确认对应关系；基于几何条件选区通常更便于复现。

当前转换例只有一个单元，适合检验文件接口。研究训练应处理具有多个入口、出口、壁面和内部区域的网格，并用流量收支或区内积分验证分区确实被模型使用。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 3.522 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/split_boundary`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/11_网格转换与电极面/代码/split_electrode。当前目录按 v2512 运行并重写说明；原始资料未修改。
