#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
topoSet > log.topoSet 2>&1
createPatch -overwrite > log.createPatch 2>&1
renumberMesh -overwrite > log.renumberMesh 2>&1
checkMesh > log.checkMesh.2 2>&1
touch case.foam
