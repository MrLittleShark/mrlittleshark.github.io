#!/bin/sh
set -e

gmshToFoam cube.msh > log.gmshToFoam 2>&1
checkMesh > log.checkMesh 2>&1
touch case.foam
