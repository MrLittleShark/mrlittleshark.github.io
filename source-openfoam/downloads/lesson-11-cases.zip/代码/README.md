# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [gmsh_import](gmsh_import/README.md)
- [split_boundary](split_boundary/README.md)
