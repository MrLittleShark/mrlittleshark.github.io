# 几何VOF与非均匀被动标量：D=0 m²/s，Nx=100

本例在interIsoFoam源码中加入cGas输运方程，用具有解析解的非均匀初场检验编译、场读取、对流、扩散和守恒。相分数采用plicRDF/isoAdvection；标量采用有限体积对流扩散方程，两者共享体积通量phi。cGas不设置Henry分配，也不反馈相体积。

## 方程和解析解

∂c/∂t+U∂c/∂x=D∂²c/∂x²，U=1 m/s，x方向长度L=1 m并周期连接。初场是周期延拓高斯函数c(x,0)=Σ exp[-((x−0.25+kL)/w0)²]，w0=0.06 m。t时刻w²=w0²+4Dt，c(x,t)=Σ(w0/w)exp[-((x−Ut−0.25+kL)/w)²]。cGas量纲mol/m³，D的单位m²/s。本组D用于数值验证，不作为特定气体物性。

计算域1×0.4×0.01 m，100×20×1个单元，前后empty，上下slip且标量零梯度。气相圆盘随给定速度平移，冻结动量方程，表面张力和重力均为零。完整计算1 s，即平移一个周期。空间采用linearUpwind，时间Euler；细网格同时减半时间步，另需独立时间步研究确定误差来源。

## 代码与运行

进入本目录执行 ./Allrun.sh。脚本先生成网格和相初场，再进入src/myInterIsoScalarFoam执行wmake，回到本目录运行编译出的程序。Make/files把可执行文件写在本例源码目录内。DGas从constant/scalarTransportProperties读取，修改物性无需重新编译；改变方程才需编译。

cGas在createFields.H创建，标量方程放在压力速度循环之后，使用当前phi。该位置对动量求解中的通量一致性很重要；本例frozenFlow用于隔离输运误差。

## 验证与研究任务

以同一单元中心的周期解析解计算L1和L∞，分别记录峰值、域内总量和气相体积。D=0用于识别数值扩散；D=0.001时物理扩散导致解析峰值降低和宽度增加。不能把任意峰值衰减都判为数值误差。实际结果见测试记录和本讲课件图。

## 本次完整计算结果

本例完成完整周期或规定计算时段。各统计量直接来自实际保存场。

浓度是否在1e-6容差内非负：否，当前非受限格式出现负值，不应将其解释为物理浓度。 L1与峰值误差参照同一时刻的周期高斯解析解。

```json
{
  "cells": 2000,
  "end_time": 1.0,
  "diffusion_m2_s": 0,
  "dx": 0.01,
  "delta_t": 0.001,
  "Co": 0.1,
  "L1": 0.025624255464994566,
  "Linf": 0.22322839678531647,
  "L1_relative_to_inventory": 0.2409489669919433,
  "inventory_relative_drift": 2.579629843069142e-10,
  "initial_inventory_mol": 0.00042538892421732383,
  "final_inventory_mol": 0.00042538892432705843,
  "peak_numerical": 0.7749444300741002,
  "peak_exact_at_centres": 0.9930796124903163,
  "peak_relative_error": -0.21965528208680574,
  "gas_volume_relative_drift": -2.438937940496544e-12,
  "c_min": -0.0024729900703100004,
  "c_max": 0.7749444300741002,
  "nonnegative_within_1e_minus6": false,
  "scheme": "linearUpwind"
}
```

当前目录Allrun.sh：

```sh
#!/bin/sh
set -e
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
wmake src/myInterIsoScalarFoam > log.wmake 2>&1
./src/myInterIsoScalarFoam/myInterIsoScalarFoam > log.myInterIsoScalarFoam 2>&1
touch case.foam
```
