#!/bin/sh
set -e

wmake src/myInterFoam > log.wmake 2>&1
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
./src/myInterFoam/myInterFoam > log.myInterFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
