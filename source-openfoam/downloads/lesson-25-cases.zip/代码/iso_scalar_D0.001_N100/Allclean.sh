#!/bin/sh
set -e
foamListTimes -rm
rm -rf constant/polyMesh postProcessing VTK
rm -f log.* case.foam
