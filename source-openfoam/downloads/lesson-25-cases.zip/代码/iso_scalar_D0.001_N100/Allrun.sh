#!/bin/sh
set -e
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
wmake src/myInterIsoScalarFoam > log.wmake 2>&1
./src/myInterIsoScalarFoam/myInterIsoScalarFoam > log.myInterIsoScalarFoam 2>&1
touch case.foam
