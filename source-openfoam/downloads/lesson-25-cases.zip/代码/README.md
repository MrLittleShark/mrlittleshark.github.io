# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`iso_scalar_limited_D0_N100`。参数对照和基础验证分别见以下独立目录。

- [passive_scalar_bubble](passive_scalar_bubble/README.md)
- [iso_scalar_D0_N100](iso_scalar_D0_N100/README.md)
- [iso_scalar_D0.001_N100](iso_scalar_D0.001_N100/README.md)
- [iso_scalar_D0.001_N200](iso_scalar_D0.001_N200/README.md)
- [iso_scalar_limited_D0_N100](iso_scalar_limited_D0_N100/README.md)
