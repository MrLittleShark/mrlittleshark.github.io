# Tutorial 14: SIMPLE Algorithm

## Goal

Implement the central steps of the SIMPLE pressure-velocity coupling algorithm
directly with OpenFOAM matrices.

## Source and case

- `OFtutorial14.C` assembles and solves the momentum and pressure equations.
- `createFields.H` creates the pressure, velocity, and transport fields.
- `testCase/system/fvSolution` provides solver and SIMPLE controls.
- `testCase/system/fvSchemes` defines the discretisation schemes.

The example prioritises clarity over production convergence controls; it is
intended to expose the matrix operations and correction sequence.

## Run

```bash
./Allwmake
cd testCase
./Allrun
```

The case is meshed with `blockMesh` and then solved by `ofTutorial14`.

## Expected result

The channel develops a velocity field after the SIMPLE iterations. Inspect the
result with `viewData.pvsm` or compare it with `velocity_field.png`.
