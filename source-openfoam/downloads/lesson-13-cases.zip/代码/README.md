# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [GAMG](GAMG/README.md)
- [PCG](PCG/README.md)
- [PCG_dtHalf](PCG_dtHalf/README.md)
- [PCG_dtQuarter](PCG_dtQuarter/README.md)
