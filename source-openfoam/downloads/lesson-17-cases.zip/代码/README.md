# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

课堂主要案例：`capillary_interIsoFoam_N24`。参数对照和基础验证分别见以下独立目录。

- [interFoam_N16_theta90](interFoam_N16_theta90/README.md)
- [interFoam_N24_theta90](interFoam_N24_theta90/README.md)
- [interFoam_N32_theta90](interFoam_N32_theta90/README.md)
- [interFoam_N48_theta90](interFoam_N48_theta90/README.md)
- [interIsoFoam_N16_theta90](interIsoFoam_N16_theta90/README.md)
- [interIsoFoam_N24_theta90](interIsoFoam_N24_theta90/README.md)
- [interIsoFoam_N32_theta90](interIsoFoam_N32_theta90/README.md)
- [interIsoFoam_N48_theta90](interIsoFoam_N48_theta90/README.md)
- [capillary_interFoam_N24](capillary_interFoam_N24/README.md)
- [capillary_interFoam_N48](capillary_interFoam_N48/README.md)
- [capillary_interIsoFoam_N24](capillary_interIsoFoam_N24/README.md)
- [capillary_interIsoFoam_N48](capillary_interIsoFoam_N48/README.md)
