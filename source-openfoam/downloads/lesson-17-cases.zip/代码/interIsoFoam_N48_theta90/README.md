# interIsoFoam_N48_theta90

第 17 讲：静止气泡与寄生流。

## 算例用途

本例使用 interIsoFoam 计算无重力轴对称球泡的短时初始化响应。wedge 表示三维球形界面，应采用 Δp=2σ/R；设定半径 0.5 mm、表面张力 0.072 N/m 对应理论压差 288 Pa。setFields 按单元中心初始化，使离散体积和初始曲率随网格变化。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
interIsoFoam > log.interIsoFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `interIsoFoam` |
| system/controlDict | endTime | `0.00015` |
| system/controlDict | deltaT | `2e-06` |
| system/controlDict | writeInterval | `1.4999999999999999e-05` |
| constant/transportProperties | nu | `1e-6` |
| constant/transportProperties | sigma | `0.072` |
| 0/alpha.water | theta0 | `90` |
| system/fvSolution | nCorrectors | `3` |
| system/fvSolution | nNonOrthogonalCorrectors | `0` |

实际网格：单元数 4608。

## 文件与阅读顺序

- `0/p_rgh`：去除重力静压后的压力，单位 Pa。
- `0/U`：速度初值和各边界，单位 m/s。
- `0/alpha.water`：水体积分数初值与接触角或回流条件。
- `constant/g`：重力方向与大小。
- `constant/turbulenceProperties`：当前算例的输入文件，具体设置见文件注释。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/setFieldsDict`：当前算例的输入文件，具体设置见文件注释。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 9.327 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/interIsoFoam_N48_theta90`。测试参数与计算时段见运行记录。

## 定量分析与后续验证

实际运行区间为 0 至 0.00015 s。初始气体体积 5.157449e-10 m³，最终体积 5.157449e-10 m³，相对漂移 1.059472e-08；全部保存时刻中的最大速度为 2.703975 m/s。该速度统计不是最终时刻速度，也不能由体积漂移较小推断静态力平衡已经建立。

先在同一网格上对照 interFoam 与 interIsoFoam，再分别检查四档网格的离散初始体积、压差和速度时间曲线。压差应采用气相内部及液相远场代表值，排除界面混合单元。当前 0.15 ms 目录保留为早期响应练习；达到 4 ms 的补充算例用于继续考察毛细调整，仍需用速度与压差随时间变化判断是否趋于稳定。

## 来源

课程原有 v2512 独立算例。原始输入、Allrun.sh 及既有测试记录保留；本次补充模型说明、实际统计和后续对照要求。
