# 静止球形气泡的毛细调整：interFoam，N=24

本例分析无重力条件下域内球形气泡（球心位于轴线上 y=2 mm，半径为0.5 mm）在表面张力下的压力建立和寄生流，计算至0.004 s。与本讲0.00015 s的初始化诊断相比，持续时间约为数个毛细时间尺度。是否趋于平衡由后段速度、压差与界面变化共同判断。

## 方程与评价量

求解不可压缩两相Navier–Stokes与相分数输运，水密度998 kg/m³、表面张力0.072 N/m，几何半径约0.5 mm。毛细时间tc=sqrt(rho R³/sigma)约1.3 ms。理论Laplace压差2sigma/R约288 Pa，以初始离散体积换算等效球半径 Rv=(3Vg/4π)^(1/3)，同时列出名义几何半径的参考值。

通过5°楔形积分换算完整球体体积。以alpha.water<0.05的气相核心和alpha.water>0.95的液相计算平均压差，分别记录末时刻最大速度、所有保存时刻峰值和体积漂移。网格对照关注界面曲率离散及初始体积误差；两求解器采用同物性、几何、边界和时间设置。

## 运行

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh直接执行blockMesh、checkMesh、setFields、interFoam与速度模后处理。参数在本例字典内，完整日志和定量曲线保存在测试结果。

## 分析任务

比较压力误差、寄生流衰减和相分数极值；分别考察网格、时间步和界面重构的影响。若后段速度仍未衰减至稳定水平，应延长计算并报告实际观察区间，不以程序正常结束作为静态平衡判据。

## 本次完整计算结果

本例完成完整周期或规定计算时段。各统计量直接来自实际保存场。

本组是离散平衡诊断。体积漂移很小，但压差偏低且寄生流仍较强，尚未达到静止平衡。气液核心阈值为alpha.water<0.05与>0.95，按单元体积加权。

```json
{
  "cells": 1152,
  "initial_gas_volume": 5.166544910862815e-10,
  "final_gas_volume": 5.166544827318004e-10,
  "gas_volume_drift": -1.6170344396826408e-08,
  "end_time": 0.004,
  "max_speed_saved_times": 1.2428736733452517,
  "final_max_speed": 0.6222550783517858,
  "pressure_jump_final_Pa": 269.7051933564508,
  "pressure_reference_using_discrete_sphere_volume_Pa": 289.28458503483523,
  "pressure_relative_error": -0.06768211197989235,
  "late_pressure_mean_Pa": 270.08038436749985,
  "late_speed_max_m_s": 0.9768553592362793,
  "alpha_min": -3.66213426997e-19,
  "alpha_max": 1.00000000597,
  "capillary_time_s": 0.0013162974165776096
}
```

当前目录Allrun.sh：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
setFields > log.setFields 2>&1
interFoam > log.interFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```
