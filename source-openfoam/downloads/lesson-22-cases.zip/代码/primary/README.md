# primary

第 22 讲：稳态扩散与混合边界。

## 算例用途

平板稳态扩散：T 为无量纲标量，域高 0.001 m、D=1 m2/s。primary 底部固定 0.01、顶部固定 0；mixed 在底部增加 h=1000 m/s 的线性交换阻力。解析通量分别为 10 和 5 m/s。

本目录包含完整输入，可以复制到另一位置独立运行。目录名标出当前参数组；实际数值以下表与字典为准。

本例 T 表示无量纲标量，量纲由 dimensions 指定。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
laplacianFoam > log.laplacianFoam 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `laplacianFoam` |
| system/controlDict | endTime | `30` |
| system/controlDict | deltaT | `1` |
| system/controlDict | writeInterval | `30` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 1` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |

实际网格：单元数 480。

## 文件与阅读顺序

- `0/T`：标量初值与边界，本例物理意义见上文。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 2.66 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/primary`。测试参数与计算时段见运行记录。

## 来源

/home/shark/OpenFOAM/shark-v2512/run/电极气泡_OpenFOAM_28讲/22_电势与气泡遮蔽/代码/primary。当前目录按 v2512 运行并重写说明；原始资料未修改。

## 研究问题与验证要求

本例定位：验证算例。保留，补充推导、定量定义和参数研究。

从面到单元中心距离推导mixed权重，不能在改变网格后沿用原权重。用解析通量、线性剖面和边界收支分别检查离散边界及稳态解。全Neumann边界需另满足通量兼容条件及参考值条件。

应量化的内容：Robin离散系数、解析通量、稳态唯一性和矩阵边界处理。采用本例实际字典与输出记录分析，各误差指标须注明空间区域、时间区间及归一化分母。

已有运行数据（指标定义见数值检查记录）：

- `boundary_flux`：10.000000000003334
