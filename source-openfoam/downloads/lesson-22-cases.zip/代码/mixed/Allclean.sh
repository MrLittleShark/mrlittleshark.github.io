#!/bin/sh
set -e

foamListTimes -rm
rm -rf constant/polyMesh processor* postProcessing VTK
rm -f log.* case.foam
