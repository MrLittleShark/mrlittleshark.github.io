# 本讲算例

加载OpenCFD v2512环境后，进入具体目录执行 `./Allrun.sh`。每个目录含完整输入、必要源码及运行说明。

- [limitedLinear_Co0.2](limitedLinear_Co0.2/README.md)
- [limitedLinear_Co0.5](limitedLinear_Co0.5/README.md)
- [limitedLinear_Co0.8](limitedLinear_Co0.8/README.md)
- [linearUpwind_Co0.2](linearUpwind_Co0.2/README.md)
- [linearUpwind_Co0.5](linearUpwind_Co0.5/README.md)
- [linearUpwind_Co0.8](linearUpwind_Co0.8/README.md)
- [linear_Co0.2](linear_Co0.2/README.md)
- [linear_Co0.5](linear_Co0.5/README.md)
- [linear_Co0.8](linear_Co0.8/README.md)
- [upwind_Co0.2](upwind_Co0.2/README.md)
- [upwind_Co0.5](upwind_Co0.5/README.md)
- [upwind_Co0.8](upwind_Co0.8/README.md)
- [vanLeer_Co0.2](vanLeer_Co0.2/README.md)
- [vanLeer_Co0.5](vanLeer_Co0.5/README.md)
- [vanLeer_Co0.8](vanLeer_Co0.8/README.md)
