# limitedLinear_Co0.5

第 16 讲：格式误差实验。

## 算例用途

本例求解恒速周期域内的无源标量输运，空间格式为 limitedLinear，Co 为 0.5，时间项采用隐式 Euler。对照目标是区分总量守恒、峰值保持、有界性和分布误差。相邻单元共享同一面通量，守恒仅要求内部通量成对抵消，不能据此推断波形准确。

## 运行

先在终端加载本机 v2512 环境，然后进入本算例目录：

```bash
source /usr/lib/openfoam/openfoam2512/etc/bashrc
./Allrun.sh
```

Allrun.sh 的完整内容：

```sh
#!/bin/sh
set -e

blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1
scalarTransportFoam > log.scalarTransportFoam 2>&1
postProcess -func 'mag(U)' -latestTime > log.magU 2>&1
touch case.foam
```

每条命令的输出保存为对应 log 文件。脚本从当前算例目录运行。重新计算前，应备份已有结果，再执行 `./Allclean.sh`，然后执行 `./Allrun.sh`。初始条件在 `0` 目录中设置。

## 当前参数

| 文件 | 条目 | 当前值 |
|---|---|---|
| system/controlDict | application | `scalarTransportFoam` |
| system/controlDict | endTime | `0.5` |
| system/controlDict | deltaT | `0.005` |
| system/controlDict | writeInterval | `0.5` |
| constant/transportProperties | DT | `[0 2 -1 0 0 0 0] 0` |
| system/fvSolution | nNonOrthogonalCorrectors | `1` |

实际网格：单元数 100。

## 文件与阅读顺序

- `0/U`：速度初值和各边界，单位 m/s。
- `0/T`：标量初值与边界，本例物理意义见上文。
- `constant/transportProperties`：黏度、密度或扩散系数等物性。
- `system/blockMeshDict`：坐标、块数、单元分布与边界名称。
- `system/fvSchemes`：各方程项的离散格式。
- `system/controlDict`：结束时间、时间步和输出。
- `system/fvSolution`：线性求解与压力速度循环。

## 查看结果

用 ParaView 打开 `case.foam`，点击 Apply。先显示 Surface With Edges 检查网格，再选择场量和时间。用 Plot Over Line 保存剖面，使用相同坐标和色标比较不同目录。

## 测试

本次测试状态：PASS；退出码 0；完整脚本耗时 3.116 s。时间与当前机器负载有关。

原始日志和数值检查保存在本讲 `测试结果/limitedLinear_Co0.5`。测试参数与计算时段见运行记录。

## 定量分析与后续验证

当前设定 deltaT=0.005 s、endTime=0.5 s，实际最后保存时刻为 0.5 s。比较精确解时使用该实际时刻，将 x−Ut 按域长做周期映射，并在相同单元中心位置采样。当前 L1=0.04498383，T 最小值=7.773389e-11，最大值=0.6330767；最终均值减初始均值为 7.047141e-14。该均值差不属于相对误差，均匀网格下乘总体积才得到标量积分差。

首先固定当前 Co 比较五种格式，再固定当前格式比较 Co=0.2、0.5、0.8。改变 Co 同时改变时间步，因此总误差包含空间和时间两部分，不能直接称为空间收敛阶。当前光滑高斯脉冲适合比较峰值和相位；阶跃输运需要另建完整副本检验有界性。

## 来源

课程原有 v2512 独立算例。原始输入、Allrun.sh 及既有测试记录保留；本次补充模型说明、实际统计和后续对照要求。
